<?php
require __DIR__ . '/db.php';
require_login(); $pdo = db();

$one = function (string $sql, array $a = []) use ($pdo) { $s = $pdo->prepare($sql); $s->execute($a); return (float)($s->fetchColumn() ?: 0); };
$rows = function (string $sql, array $a = []) use ($pdo) { $s = $pdo->prepare($sql); $s->execute($a); return $s->fetchAll(); };

/* ------------------------------------------------------------------
   Range: 'mtd' (month to date, default) or 'ytd' (year to date).
   $fmt is whitelisted to one of two literals, so it is safe to inline.
   ------------------------------------------------------------------ */
$range = (($_GET['range'] ?? 'mtd') === 'ytd') ? 'ytd' : 'mtd';
$isYtd = $range === 'ytd';
$fmt   = $isYtd ? '%Y' : '%Y-%m';
$cur   = $isYtd ? date('Y') : date('Y-m');
$prev  = $isYtd ? (string)((int)date('Y') - 1) : date('Y-m', strtotime('first day of last month'));

/** Financials for one period bucket. */
$metrics = function (string $period) use ($one, $fmt) {
    $rev  = $one("SELECT COALESCE(SUM(subtotal-discount),0) FROM sales WHERE strftime('{$fmt}',created_at)=?", [$period]);
    $cogs = $one("SELECT COALESCE(SUM(i.qty*i.cost),0) FROM sale_items i JOIN sales s ON s.id=i.sale_id WHERE strftime('{$fmt}',s.created_at)=?", [$period]);
    $exp  = $one("SELECT COALESCE(SUM(amount),0) FROM expenses WHERE strftime('{$fmt}',expense_date)=?", [$period]);
    $cnt  = (int)$one("SELECT COUNT(*) FROM sales WHERE strftime('{$fmt}',created_at)=?", [$period]);
    return ['revenue' => $rev, 'cost' => $cogs, 'expenses' => $exp, 'profit' => $rev - $cogs - $exp, 'count' => $cnt];
};
$m = $metrics($cur);
$p = $metrics($prev);

/** Percentage change vs the previous period; 100 when growing off zero, 0 when flat at zero. */
$delta = function (float $now, float $then): float {
    if (abs($then) < 0.005) return abs($now) < 0.005 ? 0.0 : 100.0;
    return round((($now - $then) / abs($then)) * 100, 1);
};

/* ------------------------------------------------------------------
   Chart series. Daily sales are bucketed in PHP from a single grouped
   query so PHP and SQLite never have to agree on a week-number format.
   ------------------------------------------------------------------ */
$byDate = array_column(
    $rows("SELECT date(created_at) d, SUM(total) t FROM sales WHERE date(created_at) >= date('now','-364 days') GROUP BY d"),
    't', 'd'
);
$sumDates = function (string $from, string $to) use ($byDate): float {
    $s = 0.0;
    foreach ($byDate as $d => $t) { if ($d >= $from && $d <= $to) { $s += (float)$t; } }
    return $s;
};

$daily = ['labels' => [], 'values' => []];
for ($i = 6; $i >= 0; $i--) {
    $d = date('Y-m-d', strtotime("-{$i} days"));
    $daily['labels'][] = date('D', strtotime($d));
    $daily['values'][] = (float)($byDate[$d] ?? 0);
}

$weekly = ['labels' => [], 'values' => []];
for ($i = 7; $i >= 0; $i--) {
    $end   = date('Y-m-d', strtotime('-' . ($i * 7) . ' days'));
    $start = date('Y-m-d', strtotime('-' . ($i * 7 + 6) . ' days'));
    $weekly['labels'][] = date('M j', strtotime($start));
    $weekly['values'][] = $sumDates($start, $end);
}

$byMonth = array_column($rows("SELECT strftime('%Y-%m',created_at) k, SUM(total) t FROM sales GROUP BY k"), 't', 'k');
$monthly = ['labels' => [], 'values' => []];
for ($i = 11; $i >= 0; $i--) {
    $k = date('Y-m', strtotime("first day of -{$i} month"));
    $monthly['labels'][] = strtoupper(date('M', strtotime($k . '-01')));
    $monthly['values'][] = (float)($byMonth[$k] ?? 0);
}

/* New customers per bucket (customers.created_at). */
$custByDate  = array_column($rows("SELECT date(created_at) d, COUNT(*) c FROM customers GROUP BY d"), 'c', 'd');
$custByMonth = array_column($rows("SELECT strftime('%Y-%m',created_at) k, COUNT(*) c FROM customers GROUP BY k"), 'c', 'k');
$countDates = function (string $from, string $to) use ($custByDate): int {
    $s = 0;
    foreach ($custByDate as $d => $c) { if ($d >= $from && $d <= $to) { $s += (int)$c; } }
    return $s;
};

$custWeekly = ['labels' => $weekly['labels'], 'values' => []];
for ($i = 7; $i >= 0; $i--) {
    $custWeekly['values'][] = $countDates(
        date('Y-m-d', strtotime('-' . ($i * 7 + 6) . ' days')),
        date('Y-m-d', strtotime('-' . ($i * 7) . ' days'))
    );
}
$custMonthly = ['labels' => $monthly['labels'], 'values' => []];
for ($i = 11; $i >= 0; $i--) {
    $custMonthly['values'][] = (int)($custByMonth[date('Y-m', strtotime("first day of -{$i} month"))] ?? 0);
}

json_out([
    'range'    => $range,
    'period'   => $cur,
    'previous' => $prev,

    /* KPI cards + deltas vs the previous equivalent period */
    'sales_count' => $m['count'],
    'revenue'     => $m['revenue'],
    'cost'        => $m['cost'],
    'expenses'    => $m['expenses'],
    'profit'      => $m['profit'],
    'delta'       => [
        'sales_count' => $delta((float)$m['count'], (float)$p['count']),
        'revenue'     => $delta($m['revenue'], $p['revenue']),
        'cost'        => $delta($m['cost'], $p['cost']),
        'profit'      => $delta($m['profit'], $p['profit']),
    ],

    /* Charts */
    'sales_series'    => ['daily' => $daily, 'weekly' => $weekly, 'monthly' => $monthly],
    'customer_series' => ['weekly' => $custWeekly, 'monthly' => $custMonthly],

    /* Inventory overview */
    'qty_in_hand' => $one('SELECT COALESCE(SUM(stock),0) FROM products'),
    'stock_value' => $one('SELECT COALESCE(SUM(stock*purchase_price),0) FROM products'),

    /* Stock overview */
    'low'         => (int)$one('SELECT COUNT(*) FROM products WHERE stock>0 AND stock<=min_stock'),
    'out'         => (int)$one('SELECT COUNT(*) FROM products WHERE stock<=0'),
    'items'       => (int)$one('SELECT COUNT(*) FROM products'),
    'item_groups' => (int)$one('SELECT COUNT(*) FROM categories'),
    'products'    => (int)$one("SELECT COUNT(*) FROM products WHERE status='Active'"),

    /* No. of users */
    'customers' => (int)$one('SELECT COUNT(*) FROM customers'),
    'suppliers' => (int)$one('SELECT COUNT(*) FROM suppliers'),

    /* Purchase overview (current period) */
    'purchases_count' => (int)$one("SELECT COUNT(*) FROM purchases WHERE strftime('{$fmt}',created_at)=?", [$cur]),
    'purchase_cost'   => $one("SELECT COALESCE(SUM(total),0) FROM purchases WHERE strftime('{$fmt}',created_at)=?", [$cur]),
    'purchase_paid'   => $one("SELECT COALESCE(SUM(paid),0) FROM purchases WHERE strftime('{$fmt}',created_at)=?", [$cur]),

    /* Tables */
    'recent' => $rows('SELECT s.id,s.invoice_no,s.total,s.paid,s.payment_method,s.created_at,c.name AS customer
                       FROM sales s LEFT JOIN customers c ON c.id=s.customer_id ORDER BY s.id DESC LIMIT 6'),
    'low_items' => $rows('SELECT id,name,sku,stock,min_stock,image FROM products
                          WHERE stock<=min_stock ORDER BY stock ASC, name ASC LIMIT 5'),

    /* Retained for the other pages/scripts that already read these keys */
    'today_sales'     => $one("SELECT COALESCE(SUM(total),0) FROM sales WHERE date(created_at)=date('now')"),
    'month_sales'     => $one("SELECT COALESCE(SUM(total),0) FROM sales WHERE strftime('%Y-%m',created_at)=?", [date('Y-m')]),
    'month_purchases' => $one("SELECT COALESCE(SUM(total),0) FROM purchases WHERE strftime('%Y-%m',created_at)=?", [date('Y-m')]),
    'last7'           => array_map(
        fn($i) => ['day' => date('Y-m-d', strtotime("-{$i} days")), 'total' => (float)($byDate[date('Y-m-d', strtotime("-{$i} days"))] ?? 0)],
        range(6, 0)
    ),
    'top' => $rows("SELECT i.name, SUM(i.qty) qty, SUM(i.qty*i.price) revenue FROM sale_items i
                    JOIN sales s ON s.id=i.sale_id WHERE s.created_at >= datetime('now','-30 days')
                    GROUP BY i.product_id ORDER BY qty DESC LIMIT 5"),
]);
