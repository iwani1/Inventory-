<?php
/* Role catalogue + the permission matrix behind Roles & Permissions.

   GET  -> modules, actions, roles with live member counts, and every grant
   POST -> replace one role's grants: {"role":"manager","perms":{"inventory":["view","edit"]}}

   Grants are real rows in role_permissions and are enforced by require_perm()
   in products.php, sales.php, purchases.php, stock.php, crud.php, reports.php
   and users.php. Nothing here is decorative. */
require __DIR__ . '/db.php';
$user = require_login();
$pdo = db();
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    require_perm($user, 'system', 'view');

    $counts = [];
    foreach ($pdo->query('SELECT role, COUNT(*) AS n FROM users GROUP BY role')->fetchAll() as $r) {
        $counts[$r['role']] = (int)$r['n'];
    }
    $roles = [];
    foreach (ROLE_DEFS as $key => $d) {
        $roles[] = [
            'key'         => $key,
            'name'        => $d['name'],
            'badge'       => $d['badge'],
            'description' => $d['description'],
            'members'     => $counts[$key] ?? 0,
            'locked'      => $key === 'admin', // admin bypasses the matrix; editing it would be a lie
        ];
    }
    json_out([
        'modules' => PERM_MODULES,
        'actions' => PERM_ACTIONS,
        'roles'   => $roles,
        'perms'   => all_role_perms(),
    ]);
}

if ($method === 'POST') {
    require_perm($user, 'system', 'edit');
    $b = body();
    $role = (string)($b['role'] ?? '');
    if (!isset(ROLE_DEFS[$role])) fail('Unknown role', 404);
    if ($role === 'admin') fail('The Administrator role always has full access and cannot be restricted.', 400);

    $incoming = is_array($b['perms'] ?? null) ? $b['perms'] : [];
    $rows = [];
    foreach ($incoming as $module => $acts) {
        if (!isset(PERM_MODULES[$module]) || !is_array($acts)) continue;
        foreach ($acts as $a) {
            if (isset(PERM_ACTIONS[$a])) $rows[] = [$module, (string)$a];
        }
    }
    /* Guard against an admin locking themselves out of user management. */
    if ($role === ($user['role'] ?? '')) {
        $keepsSystem = false;
        foreach ($rows as $r) { if ($r[0] === 'system' && $r[1] === 'edit') $keepsSystem = true; }
        if (!$keepsSystem) fail('You cannot remove your own ability to edit permissions.', 400);
    }

    try {
        tx(function ($p) use ($role, $rows) {
            $p->prepare('DELETE FROM role_permissions WHERE role_key=?')->execute([$role]);
            $ins = $p->prepare('INSERT OR IGNORE INTO role_permissions(role_key,module,action) VALUES(?,?,?)');
            foreach ($rows as $r) { $ins->execute([$role, $r[0], $r[1]]); }
        });
    } catch (Throwable $e) {
        fail('Could not save permissions: ' . $e->getMessage(), 500);
    }
    json_out(['ok' => true, 'role' => $role, 'saved' => count($rows), 'perms' => all_role_perms()]);
}

fail('Method not allowed', 405);
