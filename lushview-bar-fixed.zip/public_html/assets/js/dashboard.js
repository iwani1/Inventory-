/* ============================================
   Lush View Bar — Dashboard JavaScript
   Charts and Dashboard Interactions
   ============================================ */

'use strict';

/* ============================================
   Dark Mode Chart Helpers
   ============================================ */
function isDark() {
  return document.documentElement.classList.contains('dark');
}

function chartColors() {
  const dark = isDark();
  return {
    grid:    dark ? 'rgba(51,65,85,0.8)'   : 'rgba(232,237,241,0.8)',
    tick:    dark ? '#94A3B8'               : '#6B7280',
    tooltip: dark ? 'rgba(30,41,59,0.97)'  : 'rgba(23,33,43,0.95)',
  };
}

/* ============================================
   Live Data — injected by pages.js from api/dashboard.php
   Shape per period: { labels: [...], values: [...] }
   ============================================ */
let salesData    = null;
let customerData = null;

function setDashboardSeries(sales, customers) {
  salesData    = sales     || null;
  customerData = customers || null;
}

/** Normalise the API shape into the {labels, data} pair the charts consume. */
function seriesOf(src, period) {
  const s = src && src[period];
  if (!s || !Array.isArray(s.values)) return { labels: [], data: [] };
  return { labels: s.labels || [], data: s.values.map(v => Number(v) || 0) };
}

/* ============================================
   Sales Statistics Chart
   ============================================ */
let salesChart = null;

function initSalesChart(period = 'monthly') {
  const ctx = document.getElementById('salesChart');
  if (!ctx) return;

  if (!salesData) return;
  const { labels, data } = seriesOf(salesData, period);
  if (!data.length) return;
  const peakIdx = data.indexOf(Math.max(...data));

  if (salesChart) salesChart.destroy();

  salesChart = new Chart(ctx, {
    type: 'line',
    data: {
      labels,
      datasets: [{
        label: 'Sales',
        data,
        borderColor: '#E11D48',
        borderWidth: 2.5,
        tension: 0.4,
        fill: true,
        backgroundColor: (ctx) => {
          const chart = ctx.chart;
          const { ctx: c, chartArea } = chart;
          if (!chartArea) return 'transparent';
          const grad = c.createLinearGradient(0, chartArea.top, 0, chartArea.bottom);
          grad.addColorStop(0, 'rgba(225,29,72,0.18)');
          grad.addColorStop(1, 'rgba(225,29,72,0.01)');
          return grad;
        },
        pointBackgroundColor: data.map((_, i) => i === peakIdx ? '#E11D48' : 'transparent'),
        pointBorderColor: data.map((_, i) => i === peakIdx ? '#fff' : 'transparent'),
        pointBorderWidth: data.map((_, i) => i === peakIdx ? 3 : 0),
        pointRadius: data.map((_, i) => i === peakIdx ? 8 : 3),
        pointHoverRadius: 6,
        pointHoverBackgroundColor: '#E11D48',
        pointHoverBorderColor: '#fff',
        pointHoverBorderWidth: 2,
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      interaction: { mode: 'index', intersect: false },
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: chartColors().tooltip,
          padding: 12,
          cornerRadius: 10,
          titleFont: { size: 12, weight: '600' },
          bodyFont: { size: 13 },
          callbacks: {
            label: (ctx) => ` $${ctx.parsed.y.toLocaleString()}`,
          }
        }
      },
      scales: {
        x: {
          grid: { display: false },
          border: { display: false },
          ticks: {
            color: chartColors().tick,
            font: { size: 11, weight: '500' },
          }
        },
        y: {
          grid: {
            color: chartColors().grid,
            drawBorder: false,
          },
          border: { display: false, dash: [4, 4] },
          ticks: {
            color: chartColors().tick,
            font: { size: 11 },
            callback: (v) => '$' + (v >= 1000 ? (v/1000).toFixed(0) + 'k' : v),
          }
        }
      }
    }
  });
}

/* ============================================
   Customer Statistics Chart
   ============================================ */
let customerChart = null;

function initCustomerChart(period = 'monthly') {
  const ctx = document.getElementById('customerChart');
  if (!ctx) return;

  if (!customerData) return;
  const { labels, data } = seriesOf(customerData, period);
  if (!data.length) return;
  const peakIdx = data.indexOf(Math.max(...data));

  if (customerChart) customerChart.destroy();

  customerChart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels,
      datasets: [{
        label: 'Customers',
        data,
        backgroundColor: data.map((_, i) => i === peakIdx ? '#E11D48' : 'rgba(225,29,72,0.18)'),
        borderColor: data.map((_, i) => i === peakIdx ? '#E11D48' : 'transparent'),
        borderWidth: 0,
        borderRadius: 6,
        borderSkipped: false,
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      interaction: { mode: 'index', intersect: false },
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: chartColors().tooltip,
          padding: 12,
          cornerRadius: 10,
          callbacks: {
            label: (ctx) => ` ${ctx.parsed.y} customers`,
          }
        }
      },
      scales: {
        x: {
          grid: { display: false },
          border: { display: false },
          ticks: { color: chartColors().tick, font: { size: 11, weight: '500' } }
        },
        y: {
          grid: { color: chartColors().grid },
          border: { display: false },
          ticks: {
            color: chartColors().tick,
            font: { size: 11 },
            callback: (v) => v >= 1000 ? (v/1000).toFixed(1) + 'k' : v,
          }
        }
      }
    }
  });
}

/* ============================================
   Chart Period Switcher
   ============================================ */
function initChartFilters() {
  // Sales chart filter
  document.querySelectorAll('[data-sales-period]').forEach(btn => {
    btn.addEventListener('click', function() {
      document.querySelectorAll('[data-sales-period]').forEach(b => {
        b.classList.remove('btn-primary');
        b.classList.add('btn-secondary');
      });
      this.classList.remove('btn-secondary');
      this.classList.add('btn-primary');
      _currentSalesPeriod = this.dataset.salesPeriod;
      initSalesChart(_currentSalesPeriod);
    });
  });

  // Customer chart filter
  document.querySelectorAll('[data-customer-period]').forEach(btn => {
    btn.addEventListener('click', function() {
      document.querySelectorAll('[data-customer-period]').forEach(b => {
        b.classList.remove('btn-primary');
        b.classList.add('btn-secondary');
      });
      this.classList.remove('btn-secondary');
      this.classList.add('btn-primary');
      _currentCustomerPeriod = this.dataset.customerPeriod;
      initCustomerChart(_currentCustomerPeriod);
    });
  });
}

/* ============================================
   Date Filter
   ============================================ */
function initDateFilter() {
  document.querySelectorAll('[data-date-filter]').forEach(btn => {
    btn.addEventListener('click', function() {
      document.querySelectorAll('[data-date-filter]').forEach(b => {
        b.classList.remove('active');
        b.style.background = '';
        b.style.color = '';
        b.style.borderColor = '';
      });
      this.classList.add('active');
      this.style.background = 'rgba(255,255,255,0.95)';
      this.style.color = 'var(--primary)';
      this.style.borderColor = 'rgba(255,255,255,0.95)';
      const range = this.dataset.dateFilter;
      if (typeof window.onDashboardRangeChange === 'function') {
        window.onDashboardRangeChange(range);
      } else {
        Toast.info(`Filtered: ${this.textContent.trim()}`, 'Date Filter');
      }
    });
  });
}

/* ============================================
   Dashboard Init
   ============================================ */
let _currentSalesPeriod   = 'monthly';
let _currentCustomerPeriod = 'monthly';

/* pages.js renders the dashboard markup asynchronously, so it calls this
   once the canvases exist rather than the file booting itself on
   DOMContentLoaded (which used to race the injector). */
function initDashboard(opts = {}) {
  if (opts.sales || opts.customers) setDashboardSeries(opts.sales, opts.customers);
  if (opts.salesPeriod)    _currentSalesPeriod    = opts.salesPeriod;
  if (opts.customerPeriod) _currentCustomerPeriod = opts.customerPeriod;
  initSalesChart(_currentSalesPeriod);
  initCustomerChart(_currentCustomerPeriod);
  initChartFilters();
  initDateFilter();
  animateCounters();
}

// Re-draw charts when dark mode is toggled so grid/tick colors update
document.addEventListener('themechange', () => {
  if (document.getElementById('salesChart'))   initSalesChart(_currentSalesPeriod);
  if (document.getElementById('customerChart')) initCustomerChart(_currentCustomerPeriod);
});

/* ============================================
   Counter Animation
   ============================================ */
function animateCounters() {
  document.querySelectorAll('[data-count]').forEach(el => {
    const target = parseFloat(el.dataset.count);
    const prefix = el.dataset.prefix || '';
    const suffix = el.dataset.suffix || '';
    const isDecimal = String(target).includes('.');
    const duration = 1200;
    const start = performance.now();

    function update(ts) {
      const progress = Math.min((ts - start) / duration, 1);
      const ease = 1 - Math.pow(1 - progress, 3);
      const value = target * ease;
      el.textContent = prefix + (isDecimal ? value.toFixed(1) : Math.round(value).toLocaleString()) + suffix;
      if (progress < 1) requestAnimationFrame(update);
    }

    requestAnimationFrame(update);
  });
}
