/* ============================================
   Lush View Bar — Dynamic Page Engine
   Fully connected to PHP & SQLite backend
   ============================================ */

'use strict';

window.CUR = (typeof localStorage !== 'undefined' && localStorage.getItem('lushview_cur')) || window.CUR || 'GH₵';
window.BIZ = (typeof localStorage !== 'undefined' && localStorage.getItem('lushview_biz')) || window.BIZ || 'Lush View Bar';
const CUR = window.CUR, BIZ = window.BIZ;

const money = n => CUR + (Number(n) || 0).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2});
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const $ = (s, r = document) => r.querySelector(s);
const root = () => document.getElementById('app-root');
const bad = e => Toast.error(e.message || String(e), 'Error');
const day = s => String(s || '').slice(0, 10);
const today = () => new Date().toISOString().slice(0, 10);
const sub = t => `<div style="color:var(--muted);font-size:12px">${t}</div>`;
const head = (t, s, btn = '') => `<div class="page-header"><div><h1 class="page-title">${t}</h1><p class="page-subtitle">${s}</p></div><div class="page-header-actions">${btn}</div></div>`;
const card = (t, b) => `<div class="card" style="padding:18px"><h3 style="font-weight:700;margin-bottom:12px">${t}</h3>${b}</div>`;
const stat = (l, v, n = '') => `<div class="card" style="padding:18px"><div style="color:var(--muted);font-size:12px;font-weight:600">${l}</div><div style="font-size:24px;font-weight:700;margin-top:6px">${v}</div><div style="font-size:12px;color:var(--muted);margin-top:2px">${n}</div></div>`;
const cards = h => `<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:16px;margin-bottom:20px">${h}</div>`;
const two = h => `<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:16px">${h}</div>`;
const fld = (l, h) => `<div><label class="form-label">${l}</label>${h}</div>`;
const row = h => `<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:14px;margin-bottom:16px">${h}</div>`;

function tbl(cols, rows, empty = 'Nothing here yet.') {
  if (!rows.length) return `<div style="padding:40px;text-align:center;color:var(--muted)">${empty}</div>`;
  return `<div style="overflow-x:auto"><table class="data-table"><thead><tr>${cols.map(c => `<th>${c[0]}</th>`).join('')}</tr></thead><tbody>${rows.map(r => `<tr>${cols.map(c => `<td>${c[1](r)}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;
}

function modal(title, body, label, onSave) {
  Modal.show({
    title, size: 'md', body,
    footer: `<button class="btn btn-secondary" onclick="document.querySelector('.modal-backdrop')?.remove()">Close</button>${onSave ? `<button class="btn btn-primary" id="m-save">${label}</button>` : ''}`
  });
  setTimeout(() => {
    const b = $('#m-save');
    if (b) b.onclick = async () => {
      b.disabled = true;
      try {
        if (await onSave() !== false) document.querySelector('.modal-backdrop')?.remove();
      } catch (e) { bad(e); }
      b.disabled = false;
    };
  }, 30);
}

/* ============================================
   Generic CRUD Pages (Categories, Brands, Units, Customers, Suppliers, Expenses)
   ============================================ */
const nameCol = ['Name', r => `<b>${esc(r.name)}</b>`], created = ['Added', r => esc(day(r.created_at))];
const party = (one) => ({
  one,
  f: [['name','Name','text',1],['company','Company'],['email','Email','email'],['phone','Phone'],['city','City'],['address','Address']],
  c: [[one, r => `<b>${esc(r.name)}</b>${sub(esc(r.company || ''))}`], ['Contact', r => `${esc(r.email || '')}${sub(esc(r.phone || ''))}`], ['City', r => esc(r.city || '')]]
});

const CRUDS = {
  categories: {title: 'Categories', s: 'Group your products into logical departments.', one: 'Category', f: [['name','Name','text',1]], c: [nameCol, created]},
  brands: {title: 'Brands', s: 'Manage manufacturer brands.', one: 'Brand', f: [['name','Name','text',1]], c: [nameCol, created]},
  units: {title: 'Units of Measurement', s: 'Standard product measurement units (Piece, Box, Kg, Liter...).', one: 'Unit', f: [['name','Name','text',1]], c: [nameCol, created]},
  customers: {title: 'Customers', s: 'Manage client directory and contact info.', ...party('Customer')},
  suppliers: {title: 'Suppliers', s: 'Manage vendor directory and supply contacts.', ...party('Supplier')},
  expenses: {
    title: 'Expenses', s: 'Track operating overhead (utilities, rent, logistics...).', one: 'Expense',
    f: [['title','Title','text',1],['category','Category'],['amount','Amount','number',1],['expense_date','Date','date'],['note','Note']],
    c: [['Title', r => `<b>${esc(r.title)}</b>${sub(esc(r.note || ''))}`], ['Category', r => esc(r.category || 'General')], ['Amount', r => money(r.amount)], ['Date', r => esc(r.expense_date || day(r.created_at))]]
  },
};

async function crudPage(name) {
  const C = CRUDS[name]; let rows = [];
  root().innerHTML = head(C.title, C.s, `<button class="btn btn-primary" id="add">+ Add ${C.one}</button>`) +
    `<div class="card" style="padding:0"><div style="padding:14px"><input id="q" class="form-input" placeholder="Search..."></div><div id="t"></div></div>`;
  const draw = () => {
    const q = $('#q').value.toLowerCase(), list = rows.filter(r => JSON.stringify(Object.values(r)).toLowerCase().includes(q));
    $('#t').innerHTML = tbl([...C.c, ['', r => `<button class="btn btn-secondary btn-sm" data-e="${r.id}">Edit</button> <button class="btn btn-danger btn-sm" data-d="${r.id}">Delete</button>`]], list);
  };
  const load = async () => { rows = await api('crud.php?e=' + name); draw(); };
  const form = r => {
    modal((r ? 'Edit ' : 'Add ') + C.one,
      `<div style="display:flex;flex-direction:column;gap:12px">${C.f.map(([k, l, t = 'text', req]) => fld(l + (req ? ' *' : ''), `<input class="form-input" data-k="${k}" type="${t}" ${t === 'number' ? 'step="0.01" min="0"' : ''} value="${esc(r ? r[k] : (t === 'date' ? today() : ''))}">`)).join('')}</div>`,
      'Save', async () => {
        const body = {}; document.querySelectorAll('.modal-body [data-k]').forEach(i => body[i.dataset.k] = i.value);
        await api('crud.php?e=' + name + (r ? '&id=' + r.id : ''), {method: r ? 'PUT' : 'POST', body});
        Toast.success(C.one + ' saved', 'Done'); load();
      });
  };
  $('#add').onclick = () => form(null); $('#q').oninput = draw;
  $('#t').onclick = ev => {
    const e = ev.target.closest('[data-e]'), d = ev.target.closest('[data-d]');
    if (e) form(rows.find(r => r.id == e.dataset.e));
    if (d) Modal.confirm({
      title: 'Delete ' + C.one, message: 'This cannot be undone.', type: 'danger', confirmText: 'Delete',
      onConfirm: () => api('crud.php?e=' + name + '&id=' + d.dataset.d, {method: 'DELETE'}).then(() => { Toast.success('Deleted', 'Done'); load(); }).catch(bad)
    });
  };
  try { await load(); } catch (e) { bad(e); }
}

/* ============================================
   Stock Adjustment
   ============================================ */
async function stockPage() {
  let prods = await api('products.php');
  const opts = () => prods.map(p => `<option value="${p.id}">${esc(p.name)} (${esc(p.sku)}) — ${p.stock} in stock</option>`).join('');
  root().innerHTML = head('Stock Adjustment', 'Correct stock counts. Every change is logged in the audit trail below.') +
    `<div class="card" style="padding:18px;margin-bottom:20px">${row(
      fld('Product', `<select id="sp" class="form-input form-select">${opts()}</select>`) +
      fld('Action', `<select id="st" class="form-input form-select"><option value="add">Add stock (+)</option><option value="remove">Remove stock (-)</option></select>`) +
      fld('Quantity', `<input id="sq" type="number" min="0" step="any" class="form-input" placeholder="0">`) +
      fld('Reason / Note', `<input id="sn" class="form-input" placeholder="e.g. damaged, audit recount, return">`))}
    <button class="btn btn-primary" id="go">Apply adjustment</button></div><div class="card" id="mv" style="padding:0"></div>`;
  const load = async () => {
    const m = await api('stock.php');
    $('#mv').innerHTML = tbl([['Date', r => esc(day(r.created_at))], ['Product', r => `<b>${esc(r.name)}</b>${sub(esc(r.sku))}`], ['Type', r => `<span class="badge badge-info">${esc(r.type)}</span>`],
      ['Qty', r => `<b style="color:${r.qty < 0 ? 'var(--danger)' : 'var(--primary)'}">${r.qty > 0 ? '+' : ''}${r.qty}</b>`], ['Note', r => esc(r.note || '—')]], m, 'No movements yet.');
  };
  $('#go').onclick = async () => {
    try {
      await api('stock.php', {method: 'POST', body: {product_id: $('#sp').value, type: $('#st').value, qty: $('#sq').value, note: $('#sn').value}});
      Toast.success('Stock updated successfully', 'Done'); $('#sq').value = ''; $('#sn').value = '';
      prods = await api('products.php'); const v = $('#sp').value; $('#sp').innerHTML = opts(); $('#sp').value = v; load();
    } catch (e) { bad(e); }
  };
  load().catch(bad);
}

/* ============================================
   Invoice Modal & Print
   ============================================ */
const invHTML = s => `<div style="font-family:sans-serif;max-width:560px;margin:auto;color:#111;padding:20px;"><div style="display:flex;justify-content:space-between;border-bottom:2px solid #E11D48;padding-bottom:12px;margin-bottom:16px;"><div><h2 style="margin:0;color:#E11D48;">${esc(BIZ)}</h2><p style="color:#666;margin:2px 0;font-size:13px;">Inventory & POS Management</p></div><div style="text-align:right;"><h3 style="margin:0;">INVOICE</h3><div style="font-size:14px;font-weight:700;">${esc(s.invoice_no)}</div><div style="font-size:12px;color:#666;">Date: ${esc(day(s.created_at))}</div></div></div>
<p style="font-size:14px;margin-bottom:16px;"><strong>Billed To:</strong> ${esc(s.customer || 'Walk-in Customer')}</p>
<table style="width:100%;border-collapse:collapse;font-size:13px;margin-bottom:16px;"><tr style="background:#f3f4f6;text-align:left;"><th style="padding:8px;">Item</th><th style="padding:8px;text-align:center;">Qty</th><th style="padding:8px;text-align:right;">Price</th><th style="padding:8px;text-align:right;">Total</th></tr>
${s.items.map(i => `<tr style="border-bottom:1px solid #e5e7eb;"><td style="padding:8px;">${esc(i.name)}</td><td style="padding:8px;text-align:center;">${i.qty}</td><td style="padding:8px;text-align:right;">${money(i.price)}</td><td style="padding:8px;text-align:right;">${money(i.qty * i.price)}</td></tr>`).join('')}</table>
<div style="text-align:right;font-size:13px;line-height:1.7;">Subtotal: ${money(s.subtotal)}<br>Discount: -${money(s.discount)}<br>Tax (${s.tax_percent}%): ${money(s.tax)}<br><div style="font-size:16px;font-weight:700;margin:6px 0;border-top:1px solid #ccc;padding-top:4px;">Grand Total: ${money(s.total)}</div>Paid: ${money(s.paid)} (${esc(s.payment_method)})<br><span style="color:${s.paid >= s.total ? '#BE123C' : '#DC2626'};font-weight:700;">Balance Due: ${money(s.total - s.paid)}</span></div></div>`;

async function showInvoice(id) {
  const s = await api('sales.php?id=' + id), html = invHTML(s);
  modal('Invoice ' + s.invoice_no, html, 'Print', () => {
    const w = window.open('', '_blank'); w.document.write('<!DOCTYPE html><html><head><title>' + esc(s.invoice_no) + '</title></head><body>' + html + '</body></html>'); w.document.close(); w.focus(); w.print(); return false;
  });
}

/* ============================================
   Invoices List Page
   ============================================ */
async function invoicesListPage() {
  const rows = await api('sales.php');
  const totalInvoiced = rows.reduce((a, r) => a + r.total, 0);
  const totalPaid = rows.reduce((a, r) => a + r.paid, 0);
  const totalOwing = totalInvoiced - totalPaid;

  root().innerHTML = head('Invoices', 'Track accounts receivable, due dates, and billing receipts.', `<a class="btn btn-primary" href="../sales/add-sale.html">+ Create Invoice</a>`) +
    cards(
      stat('Total Invoiced', money(totalInvoiced), rows.length + ' invoices issued') +
      stat('Collected', money(totalPaid), totalInvoiced > 0 ? (totalPaid / totalInvoiced * 100).toFixed(1) + '% collected' : '100%') +
      stat('Outstanding', money(totalOwing), rows.filter(r => r.paid < r.total).length + ' invoices pending')
    ) +
    `<div class="card" style="padding:0">
      <div style="padding:14px;display:flex;gap:12px;flex-wrap:wrap;">
        <input id="q" class="form-input flex-1" style="min-width:200px" placeholder="Search invoice #, customer...">
        <select id="sf" class="form-input form-select" style="width:160px">
          <option value="all">All Statuses</option>
          <option value="paid">Paid</option>
          <option value="owing">Pending / Owing</option>
        </select>
      </div>
      <div id="t"></div>
    </div>`;

  const draw = () => {
    const q = $('#q').value.toLowerCase();
    const sf = $('#sf').value;
    const list = rows.filter(r => {
      const matchQ = (r.invoice_no || '').toLowerCase().includes(q) || (r.customer || '').toLowerCase().includes(q);
      const isPaid = r.paid >= r.total;
      const matchS = sf === 'all' || (sf === 'paid' && isPaid) || (sf === 'owing' && !isPaid);
      return matchQ && matchS;
    });

    $('#t').innerHTML = tbl([
      ['Invoice #', r => `<a href="invoice-details.html?id=${r.id}" style="color:var(--primary);font-weight:700;font-family:monospace;text-decoration:none;">${esc(r.invoice_no)}</a>`],
      ['Date', r => esc(day(r.created_at))],
      ['Customer', r => `<b>${esc(r.customer || 'Walk-in')}</b>`],
      ['Total', r => `<b>${money(r.total)}</b>`],
      ['Paid', r => money(r.paid)],
      ['Balance', r => `<span style="color:${r.total - r.paid > 0 ? 'var(--danger)' : 'var(--muted)'}">${money(r.total - r.paid)}</span>`],
      ['Status', r => r.paid >= r.total ? '<span class="badge badge-success">Paid</span>' : '<span class="badge badge-warning">Owing</span>'],
      ['Action', r => `<a href="invoice-details.html?id=${r.id}" class="btn btn-secondary btn-sm">View</a> <button class="btn btn-secondary btn-sm" data-inv="${r.id}">Print</button>`]
    ], list, 'No invoices found.');
  };

  $('#q').oninput = draw;
  $('#sf').onchange = draw;
  $('#t').onclick = e => {
    const b = e.target.closest('[data-inv]');
    if (b) showInvoice(b.dataset.inv).catch(bad);
  };
  draw();
}

/* ============================================
   Invoice Details Page
   ============================================ */
async function invoiceDetailsPage() {
  const urlParams = new URLSearchParams(window.location.search);
  const id = urlParams.get('id');
  if (!id) {
    root().innerHTML = `<div class="card" style="padding:40px;text-align:center;"><h2>No invoice specified</h2><p><a href="invoices.html" class="btn btn-primary" style="margin-top:16px;">Back to Invoices</a></p></div>`;
    return;
  }
  const s = await api('sales.php?id=' + id);
  const isPaid = s.paid >= s.total;

  root().innerHTML = `
    <div class="page-header">
      <div>
        <div class="breadcrumb"><a href="../dashboard.html">Home</a><span class="sep">/</span><a href="invoices.html">Invoices</a><span class="sep">/</span><span class="current">${esc(s.invoice_no)}</span></div>
        <div class="flex items-center gap-3 mt-1">
          <h1 class="page-title mb-0">${esc(s.invoice_no)}</h1>
          <span class="badge ${isPaid ? 'badge-success' : 'badge-warning'}">${isPaid ? 'Paid' : 'Pending Balance'}</span>
        </div>
      </div>
      <div class="page-header-actions">
        <a href="invoices.html" class="btn btn-secondary">Back to Invoices</a>
        <button class="btn btn-primary" id="print-btn">Print Invoice</button>
      </div>
    </div>

    <div class="card" style="padding:28px;max-width:800px;margin:auto;">
      <div style="display:flex;justify-content:space-between;border-bottom:2px solid var(--primary);padding-bottom:16px;margin-bottom:20px;">
        <div>
          <h2 style="margin:0;font-size:22px;color:var(--primary);">${esc(BIZ)}</h2>
          <div style="color:var(--muted);font-size:13px;margin-top:4px;">Official Invoice Receipt</div>
        </div>
        <div style="text-align:right;">
          <div style="font-size:18px;font-weight:700;">${esc(s.invoice_no)}</div>
          <div style="font-size:13px;color:var(--muted);">Date: ${esc(day(s.created_at))}</div>
        </div>
      </div>

      <div style="margin-bottom:24px;background:var(--background);padding:14px;border-radius:10px;">
        <div style="font-size:12px;color:var(--muted);font-weight:600;text-transform:uppercase;">Customer Details</div>
        <div style="font-size:16px;font-weight:700;margin-top:2px;">${esc(s.customer || 'Walk-in Customer')}</div>
        <div style="font-size:13px;color:var(--muted);margin-top:2px;">Payment Method: ${esc(s.payment_method)}</div>
      </div>

      <div style="margin-bottom:24px;">
        <table class="data-table">
          <thead>
            <tr>
              <th>Item / Product</th>
              <th style="text-align:center;width:90px;">Qty</th>
              <th style="text-align:right;width:130px;">Unit Price</th>
              <th style="text-align:right;width:140px;">Total</th>
            </tr>
          </thead>
          <tbody>
            ${s.items.map(i => `
              <tr>
                <td><b>${esc(i.name)}</b></td>
                <td style="text-align:center;">${i.qty}</td>
                <td style="text-align:right;">${money(i.price)}</td>
                <td style="text-align:right;font-weight:600;">${money(i.qty * i.price)}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>

      <div style="display:flex;justify-content:flex-end;">
        <div style="min-width:280px;font-size:14px;line-height:2;">
          <div style="display:flex;justify-content:space-between;"><span>Subtotal:</span> <span>${money(s.subtotal)}</span></div>
          <div style="display:flex;justify-content:space-between;color:var(--muted);"><span>Discount:</span> <span>-${money(s.discount)}</span></div>
          <div style="display:flex;justify-content:space-between;color:var(--muted);"><span>Tax (${s.tax_percent}%):</span> <span>+${money(s.tax)}</span></div>
          <div style="display:flex;justify-content:space-between;font-size:18px;font-weight:700;border-top:1px solid var(--border);padding-top:6px;margin-top:6px;"><span>Total:</span> <span style="color:var(--primary);">${money(s.total)}</span></div>
          <div style="display:flex;justify-content:space-between;"><span>Amount Paid:</span> <span>${money(s.paid)}</span></div>
          <div style="display:flex;justify-content:space-between;font-weight:700;color:${isPaid ? 'var(--primary)' : 'var(--danger)'};"><span>Balance Due:</span> <span>${money(s.total - s.paid)}</span></div>
        </div>
      </div>
    </div>
  `;

  $('#print-btn').onclick = () => {
    const html = invHTML(s);
    const w = window.open('', '_blank');
    w.document.write('<!DOCTYPE html><html><head><title>' + esc(s.invoice_no) + '</title></head><body>' + html + '</body></html>');
    w.document.close();
    w.focus();
    w.print();
  };
}

/* ============================================
   Product Details Page
   ============================================ */
async function productDetailsPage() {
  const urlParams = new URLSearchParams(window.location.search);
  const id = urlParams.get('id');
  if (!id) {
    root().innerHTML = `<div class="card" style="padding:40px;text-align:center;"><h2>No product selected</h2><p><a href="products.html" class="btn btn-primary" style="margin-top:16px;">Back to Products</a></p></div>`;
    return;
  }

  const [p, movements] = await Promise.all([
    api('products.php?id=' + id),
    api('stock.php?product_id=' + id).catch(() => [])
  ]);

  const marginVal = p.sellingPrice - p.purchasePrice;
  const marginPct = p.purchasePrice > 0 ? (marginVal / p.purchasePrice * 100).toFixed(1) : '100';

  root().innerHTML = `
    <div class="page-header">
      <div>
        <div class="breadcrumb"><a href="../dashboard.html">Home</a><span class="sep">/</span><a href="products.html">Products</a><span class="sep">/</span><span class="current">${esc(p.name)}</span></div>
        <div class="flex items-center gap-3 mt-1">
          <h1 class="page-title mb-0">${esc(p.name)}</h1>
          <span class="badge ${p.stock <= 0 ? 'badge-danger' : p.stock <= p.minStock ? 'badge-warning' : 'badge-success'}">${p.stock <= 0 ? 'Out of Stock' : p.stock <= p.minStock ? 'Low Stock' : 'In Stock'}</span>
          <span class="badge badge-info">${esc(p.category)}</span>
        </div>
      </div>
      <div class="page-header-actions">
        <a href="products.html" class="btn btn-secondary">Back</a>
        <a href="stock-adjustment.html" class="btn btn-secondary">Adjust Stock</a>
        <a href="add-product.html?id=${p.id}" class="btn btn-primary">Edit Product</a>
      </div>
    </div>

    ${cards(
      stat('Current Stock', p.stock + ' ' + (p.unit || 'units'), `Min: ${p.minStock} | Max: ${p.maxStock || '∞'}`) +
      stat('Selling Price', money(p.sellingPrice), `Cost: ${money(p.purchasePrice)}`) +
      stat('Profit Margin', money(marginVal), `${marginPct}% markup`) +
      stat('Stock Asset Value', money(p.stock * p.purchasePrice), `Retail: ${money(p.stock * p.sellingPrice)}`)
    )}

    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:20px;margin-bottom:24px;">
      <div class="card" style="padding:20px;">
        <h3 style="font-weight:700;margin-bottom:14px;border-bottom:1px solid var(--border);padding-bottom:8px;">Specifications</h3>
        <div style="display:flex;flex-direction:column;gap:10px;font-size:13px;">
          <div style="display:flex;justify-content:space-between;"><span style="color:var(--muted)">SKU:</span> <b>${esc(p.sku)}</b></div>
          <div style="display:flex;justify-content:space-between;"><span style="color:var(--muted)">Barcode:</span> <span>${esc(p.barcode || '—')}</span></div>
          <div style="display:flex;justify-content:space-between;"><span style="color:var(--muted)">Brand:</span> <span>${esc(p.brand)}</span></div>
          <div style="display:flex;justify-content:space-between;"><span style="color:var(--muted)">Category:</span> <span>${esc(p.category)}</span></div>
          <div style="display:flex;justify-content:space-between;"><span style="color:var(--muted)">Unit:</span> <span>${esc(p.unit)}</span></div>
          <div style="display:flex;justify-content:space-between;"><span style="color:var(--muted)">Status:</span> <span class="badge ${p.status === 'Active' ? 'badge-success' : 'badge-gray'}">${esc(p.status)}</span></div>
        </div>
      </div>

      <div class="card" style="padding:20px;">
        <h3 style="font-weight:700;margin-bottom:14px;border-bottom:1px solid var(--border);padding-bottom:8px;">Description</h3>
        <p style="font-size:13px;color:var(--text);line-height:1.6;">${esc(p.description || 'No description provided.')}</p>
      </div>
    </div>

    <div class="card" style="padding:0;">
      <div style="padding:16px 20px;border-bottom:1px solid var(--border);"><h3 style="font-weight:700;margin:0;">Stock Movement Audit Trail</h3></div>
      ${tbl([
        ['Date', r => esc(day(r.created_at))],
        ['Type', r => `<span class="badge badge-info">${esc(r.type)}</span>`],
        ['Qty Change', r => `<b style="color:${r.qty < 0 ? 'var(--danger)' : 'var(--primary)'}">${r.qty > 0 ? '+' : ''}${r.qty}</b>`],
        ['Note', r => esc(r.note || '—')]
      ], movements, 'No stock movements recorded for this product yet.')}
    </div>
  `;
}

/* ============================================
   Document Page (New Sale / New Purchase)
   ============================================ */
async function docPage(kind) {
  const sale = kind === 'sale';
  const [prods, parties] = await Promise.all([api('products.php'), api('crud.php?e=' + (sale ? 'customers' : 'suppliers'))]);
  const P = prods.filter(p => p.status === 'Active'); let L = [{}], paidEdited = false;
  root().innerHTML = head(sale ? 'New Sale' : 'New Purchase', sale ? 'Scan or pick products, then complete the sale.' : 'Record goods received from supplier.') +
    `<div class="card" style="padding:18px;margin-bottom:16px">${row(
      fld(sale ? 'Customer' : 'Supplier', `<select id="party" class="form-input form-select"><option value="">— ${sale ? 'Walk-in Customer' : 'Select Supplier'} —</option>${parties.map(x => `<option value="${x.id}">${esc(x.name)}${x.company ? ' (' + esc(x.company) + ')' : ''}</option>`).join('')}</select>`) +
      (sale ? fld('Payment Method', `<select id="pay" class="form-input form-select"><option>Cash</option><option>Mobile Money</option><option>Card</option><option>Bank Transfer</option><option>Credit</option></select>`)
            : fld('Purchase Date', `<input id="pdate" type="date" class="form-input" value="${today()}">`)) +
      (!sale ? fld('Supplier Invoice / Ref #', `<input id="pref" class="form-input" placeholder="e.g. PO-98123">`) : '') +
      (sale ? fld('Barcode / SKU Search', `<input id="scan" class="form-input" placeholder="Scan SKU or press Enter">`) : ''))}</div>
    <div class="card" style="padding:0;margin-bottom:16px"><div id="lines"></div>
    <div style="padding:12px 16px;border-top:1px solid var(--border)"><button class="btn btn-secondary btn-sm" id="addl">+ Add Line</button></div></div>
    <div class="card" style="padding:18px"><div style="display:flex;justify-content:flex-end;gap:24px;flex-wrap:wrap;align-items:center">
      ${sale ? `<div style="font-size:14px">Subtotal: <b id="t1"></b></div>
      <div style="display:flex;gap:8px;align-items:center">Discount <input id="disc" type="number" min="0" step="0.01" value="0" class="form-input" style="width:100px"></div>
      <div style="display:flex;gap:8px;align-items:center">Tax % <input id="tax" type="number" min="0" step="0.01" value="0" class="form-input" style="width:90px"></div>` : ''}
      <div style="font-size:18px">Total: <b id="t2"></b></div>
      <div style="display:flex;gap:8px;align-items:center">Amount Paid <input id="paid" type="number" min="0" step="0.01" class="form-input" style="width:130px"></div></div></div>
    <div style="display:flex;justify-content:flex-end;margin-top:16px"><button class="btn btn-primary btn-lg" id="go">${sale ? 'Complete Sale' : 'Save Purchase'}</button></div></div>`;

  const qty = l => l.qty ?? 1;
  const calc = () => {
    const s = L.reduce((a, l) => a + qty(l) * (+l.price || 0), 0), d = sale ? +$('#disc').value || 0 : 0, t = sale ? +$('#tax').value || 0 : 0;
    const total = Math.max(0, s - d) * (1 + t / 100);
    if (sale) $('#t1').textContent = money(s); $('#t2').textContent = money(total);
    if (!paidEdited) $('#paid').value = total.toFixed(2);
  };
  const draw = () => {
    $('#lines').innerHTML = `<table class="data-table"><thead><tr><th>Product</th><th style="width:100px">Qty</th><th style="width:130px">${sale ? 'Selling Price' : 'Unit Cost'}</th><th style="width:120px">Total</th><th></th></tr></thead><tbody>${L.map((l, i) =>
      `<tr><td><select data-i="${i}" data-k="product_id" class="form-input form-select"><option value="">— choose product —</option>${P.map(p => `<option value="${p.id}"${l.product_id == p.id ? ' selected' : ''}>${esc(p.name)} (${esc(p.sku)})${sale ? ' · ' + p.stock + ' in stock' : ''}</option>`).join('')}</select></td>
      <td><input data-i="${i}" data-k="qty" type="number" min="0" step="any" class="form-input" value="${qty(l)}"></td>
      <td><input data-i="${i}" data-k="price" type="number" min="0" step="0.01" class="form-input" value="${l.price ?? ''}"></td>
      <td id="lt${i}"><b>${money(qty(l) * (+l.price || 0))}</b></td><td><button class="btn btn-ghost btn-sm" data-rm="${i}">✕</button></td></tr>`).join('')}</tbody></table>`;
    calc();
  };
  const L$ = $('#lines');
  L$.onchange = e => { const t = e.target; if (t.dataset.k !== 'product_id') return; const l = L[t.dataset.i], p = P.find(x => x.id == t.value);
    l.product_id = t.value; l.price = p ? (sale ? p.sellingPrice : p.purchasePrice) : undefined; draw(); };
  L$.oninput = e => { const t = e.target, i = t.dataset.i; if (!i || t.dataset.k === 'product_id') return;
    L[i][t.dataset.k] = t.value === '' ? undefined : +t.value; $('#lt' + i).innerHTML = `<b>${money(qty(L[i]) * (+L[i].price || 0))}</b>`; calc(); };
  L$.onclick = e => { const b = e.target.closest('[data-rm]'); if (b) { L.splice(b.dataset.rm, 1); if (!L.length) L = [{}]; draw(); } };
  $('#addl').onclick = () => { L.push({}); draw(); };
  ['disc', 'tax'].forEach(i => $('#' + i) && ($('#' + i).oninput = calc));
  $('#paid').oninput = () => paidEdited = true;
  if (sale) $('#scan').onkeydown = e => {
    if (e.key !== 'Enter') return; e.preventDefault();
    const v = e.target.value.trim().toLowerCase(), p = P.find(x => (x.sku || '').toLowerCase() === v || (x.barcode || '').toLowerCase() === v);
    if (!p) return Toast.warning('No product with that SKU / barcode', 'Not found');
    const ex = L.find(l => l.product_id == p.id);
    if (ex) ex.qty = qty(ex) + 1; else { const blank = L.find(l => !l.product_id); const n = {product_id: String(p.id), price: p.sellingPrice};
      if (blank) Object.assign(blank, n); else L.push(n); }
    e.target.value = ''; draw();
  };
  $('#go').onclick = async () => {
    const items = L.filter(l => l.product_id).map(l => ({product_id: +l.product_id, qty: qty(l), [sale ? 'price' : 'cost']: l.price}));
    if (!items.length) return Toast.warning('Add at least one product', 'Nothing to save');
    const body = sale ? {customer_id: $('#party').value, payment_method: $('#pay').value, discount: $('#disc').value, tax_percent: $('#tax').value, paid: $('#paid').value, items}
                      : {supplier_id: $('#party').value, purchase_date: $('#pdate').value, ref: $('#pref').value, paid: $('#paid').value, items};
    $('#go').disabled = true;
    try {
      const r = await api(sale ? 'sales.php' : 'purchases.php', {method: 'POST', body});
      Toast.success(sale ? 'Sale completed successfully' : 'Purchase saved — stock updated', 'Done');
      if (sale) { await docPage('sale'); showInvoice(r.id); } else location.href = 'purchases.html';
    } catch (e) { bad(e); $('#go').disabled = false; }
  };
  draw();
}

/* ============================================
   Sales List & Report
   ============================================ */
async function salesList(report) {
  root().innerHTML = head(report ? 'Sales Report' : 'Sales', report ? 'Filter by date and analyze sales performance.' : 'All completed sales transactions.', report ? '' : `<a class="btn btn-primary" href="add-sale.html">+ New Sale</a>`) +
    (report ? `<div class="card" style="padding:14px;margin-bottom:16px;display:flex;gap:12px;align-items:end;flex-wrap:wrap"><div>${fld('From', `<input id="from" type="date" class="form-input" value="${today().slice(0, 8)}01">`)}</div><div>${fld('To', `<input id="to" type="date" class="form-input" value="${today()}">`)}</div><button class="btn btn-primary" id="run">Run Report</button></div><div id="sum"></div>` : '') +
    `<div class="card" id="t" style="padding:0"></div>`;
  const load = async () => {
    const rows = await api('sales.php' + (report ? `?from=${$('#from').value}&to=${$('#to').value}` : ''));
    if (report) $('#sum').innerHTML = cards(stat('Sales Orders', rows.length) + stat('Revenue', money(rows.reduce((a, r) => a + r.total, 0))) + stat('Collected', money(rows.reduce((a, r) => a + r.paid, 0))) + stat('Outstanding', money(rows.reduce((a, r) => a + r.total - r.paid, 0))));
    $('#t').innerHTML = tbl([['Invoice', r => `<b>${esc(r.invoice_no)}</b>`], ['Date', r => esc(day(r.created_at))], ['Customer', r => esc(r.customer || 'Walk-in')], ['Payment', r => esc(r.payment_method)],
      ['Total', r => money(r.total)], ['Status', r => r.paid >= r.total ? '<span class="badge badge-success">Paid</span>' : '<span class="badge badge-warning">Owing ' + money(r.total - r.paid) + '</span>'],
      ['', r => `<a href="../invoices/invoice-details.html?id=${r.id}" class="btn btn-secondary btn-sm">View</a> <button class="btn btn-secondary btn-sm" data-inv="${r.id}">Print</button>`]], rows, 'No sales yet.');
  };
  $('#t').onclick = e => { const b = e.target.closest('[data-inv]'); if (b) showInvoice(b.dataset.inv).catch(bad); };
  if (report) $('#run').onclick = () => load().catch(bad);
  load().catch(bad);
}

/* ============================================
   Purchases List & Report
   ============================================ */
async function purchasesList(report) {
  root().innerHTML = head(report ? 'Purchase Report' : 'Purchases', report ? 'Procurement spending and vendor purchase orders.' : 'Stock received from suppliers.', report ? '' : `<a class="btn btn-primary" href="add-purchase.html">+ New Purchase</a>`) +
    (report ? `<div class="card" style="padding:14px;margin-bottom:16px;display:flex;gap:12px;align-items:end;flex-wrap:wrap"><div>${fld('From', `<input id="from" type="date" class="form-input" value="${today().slice(0, 8)}01">`)}</div><div>${fld('To', `<input id="to" type="date" class="form-input" value="${today()}">`)}</div><button class="btn btn-primary" id="run">Run Report</button></div><div id="sum"></div>` : '') +
    `<div class="card" id="t" style="padding:0"></div>`;
  const load = async () => {
    const rows = await api('purchases.php' + (report ? `?from=${$('#from').value}&to=${$('#to').value}` : ''));
    if (report) {
      const tot = rows.reduce((a, r) => a + r.total, 0), pd = rows.reduce((a, r) => a + r.paid, 0);
      $('#sum').innerHTML = cards(stat('Purchase Orders', rows.length) + stat('Total Spent', money(tot)) + stat('Paid to Vendors', money(pd)) + stat('Outstanding', money(tot - pd)));
    }
    $('#t').innerHTML = tbl([['Date', r => esc(r.purchase_date || day(r.created_at))], ['Reference', r => esc(r.ref || '#' + r.id)], ['Supplier', r => esc(r.supplier || '—')], ['Total', r => money(r.total)],
      ['Paid', r => money(r.paid)], ['Status', r => r.paid >= r.total ? '<span class="badge badge-success">Paid</span>' : '<span class="badge badge-warning">Owing ' + money(r.total - r.paid) + '</span>']], rows, 'No purchases yet.');
  };
  if (report) $('#run').onclick = () => load().catch(bad);
  load().catch(bad);
}

/* ============================================
   Profit & Loss Report
   ============================================ */
async function profitAndLossReport() {
  root().innerHTML = head('Profit & Loss Statement', 'Comprehensive income statement, COGS analysis, overhead expenses, and net profit.') +
    `<div class="card" style="padding:14px;margin-bottom:16px;display:flex;gap:12px;align-items:end;flex-wrap:wrap">
      <div>${fld('From Date', `<input id="from" type="date" class="form-input" value="${today().slice(0, 8)}01">`)}</div>
      <div>${fld('To Date', `<input id="to" type="date" class="form-input" value="${today()}">`)}</div>
      <button class="btn btn-primary" id="run">Generate Statement</button>
    </div>
    <div id="summary"></div>
    <div id="breakdown"></div>`;

  const load = async () => {
    const data = await api(`reports.php?type=pl&from=${$('#from').value}&to=${$('#to').value}`);
    $('#summary').innerHTML = cards(
      stat('Total Revenue', money(data.revenue), `${data.sales_count} sales transactions`) +
      stat('Cost of Goods (COGS)', money(data.cogs), 'Inventory cost of items sold') +
      stat('Operating Expenses', money(data.total_expenses), `${data.expense_categories.length} expense categories`) +
      stat('Net Profit', money(data.net_profit), `${data.net_margin_percent}% Net Margin`)
    );

    $('#breakdown').innerHTML = two(
      card('Income Breakdown', `
        <div style="font-size:14px;line-height:2.2;">
          <div style="display:flex;justify-content:space-between;"><span>Gross Subtotal:</span> <b>${money(data.subtotal)}</b></div>
          <div style="display:flex;justify-content:space-between;color:var(--muted)"><span>Sales Discounts:</span> <span>-${money(data.discount)}</span></div>
          <div style="display:flex;justify-content:space-between;border-top:1px solid var(--border);padding-top:4px;"><span>Net Revenue:</span> <b>${money(data.revenue)}</b></div>
          <div style="display:flex;justify-content:space-between;color:var(--danger)"><span>Less: Cost of Goods Sold (COGS):</span> <span>-${money(data.cogs)}</span></div>
          <div style="display:flex;justify-content:space-between;font-weight:700;border-top:1px solid var(--border);padding-top:4px;color:var(--primary)"><span>Gross Profit:</span> <span>${money(data.gross_profit)}</span></div>
          <div style="display:flex;justify-content:space-between;color:var(--danger)"><span>Less: Total Operating Expenses:</span> <span>-${money(data.total_expenses)}</span></div>
          <div style="display:flex;justify-content:space-between;font-size:16px;font-weight:700;border-top:2px solid var(--border);padding-top:6px;color:${data.net_profit >= 0 ? 'var(--primary)' : 'var(--danger)'}"><span>Net Income / Profit:</span> <span>${money(data.net_profit)}</span></div>
        </div>
      `) +
      card('Expenses by Category', data.expense_categories.length ? tbl([
        ['Category', r => `<b>${esc(r.category)}</b>`],
        ['Entries', r => r.count],
        ['Amount', r => money(r.total)]
      ], data.expense_categories) : '<div style="padding:24px;text-align:center;color:var(--muted)">No expenses recorded for this period.</div>')
    );
  };

  $('#run').onclick = () => load().catch(bad);
  load().catch(bad);
}

/* ============================================
   Customer Report
   ============================================ */
async function customersReport() {
  const rows = await api('reports.php?type=customers');
  const totRev = rows.reduce((a, r) => a + r.total_spent, 0);
  const totOwing = rows.reduce((a, r) => a + r.outstanding, 0);

  root().innerHTML = head('Customer Report', 'Customer purchasing patterns, lifetime spend, and outstanding balances.') +
    cards(
      stat('Total Customers', rows.length) +
      stat('Total Customer Spend', money(totRev)) +
      stat('Total Receivables', money(totOwing), `${rows.filter(r => r.outstanding > 0).length} customers with balance`)
    ) +
    `<div class="card" style="padding:0">
      ${tbl([
        ['Customer', r => `<b>${esc(r.name)}</b>${sub(esc(r.company || ''))}`],
        ['Contact', r => `${esc(r.phone || r.email || '—')}`],
        ['Orders Count', r => r.orders_count],
        ['Total Spent', r => `<b>${money(r.total_spent)}</b>`],
        ['Total Paid', r => money(r.total_paid)],
        ['Outstanding', r => `<span style="color:${r.outstanding > 0 ? 'var(--danger)' : 'var(--muted)'}">${money(r.outstanding)}</span>`],
        ['Last Order', r => esc(r.last_order_date ? day(r.last_order_date) : 'Never')]
      ], rows, 'No customer records yet.')}
    </div>`;
}

/* ============================================
   Supplier Report
   ============================================ */
async function suppliersReport() {
  const rows = await api('reports.php?type=suppliers');
  const totSpend = rows.reduce((a, r) => a + r.total_spent, 0);
  const totOwing = rows.reduce((a, r) => a + r.outstanding, 0);

  root().innerHTML = head('Supplier Report', 'Vendor procurement volume, orders, and payment balances.') +
    cards(
      stat('Total Suppliers', rows.length) +
      stat('Procurement Spend', money(totSpend)) +
      stat('Outstanding Payables', money(totOwing), `${rows.filter(r => r.outstanding > 0).length} vendors owing`)
    ) +
    `<div class="card" style="padding:0">
      ${tbl([
        ['Supplier', r => `<b>${esc(r.name)}</b>${sub(esc(r.company || ''))}`],
        ['Contact', r => `${esc(r.phone || r.email || '—')}`],
        ['Purchase Orders', r => r.purchases_count],
        ['Total Purchased', r => `<b>${money(r.total_spent)}</b>`],
        ['Total Paid', r => money(r.total_paid)],
        ['Balance Owed', r => `<span style="color:${r.outstanding > 0 ? 'var(--danger)' : 'var(--muted)'}">${money(r.outstanding)}</span>`],
        ['Last Purchase', r => esc(r.last_purchase_date ? day(r.last_purchase_date) : 'Never')]
      ], rows, 'No supplier records yet.')}
    </div>`;
}

/* ============================================
   Inventory Report
   ============================================ */
async function inventoryReport() {
  const p = await api('products.php');
  const cost = p.reduce((a, x) => a + x.stock * x.purchasePrice, 0), retail = p.reduce((a, x) => a + x.stock * x.sellingPrice, 0);
  root().innerHTML = head('Inventory Report', 'Current stock valuation and turnover alert.') +
    cards(stat('Units in Stock', p.reduce((a, x) => a + x.stock, 0)) + stat('Value at Cost', money(cost)) + stat('Value at Retail', money(retail)) + stat('Potential Profit', money(retail - cost))) +
    `<div class="card" style="padding:0">${tbl([['Product', r => `<a href="../inventory/product-details.html?id=${r.id}" style="color:var(--text);font-weight:700;text-decoration:none;">${esc(r.name)}</a>${sub(esc(r.sku))}`], ['Category', r => esc(r.category)], ['Stock', r => `<b>${r.stock}</b>`], ['Min', r => r.minStock],
      ['Cost Value', r => money(r.stock * r.purchasePrice)], ['Retail Value', r => money(r.stock * r.sellingPrice)],
      ['Status', r => r.stock <= 0 ? '<span class="badge badge-danger">Out</span>' : r.stock <= r.minStock ? '<span class="badge badge-warning">Low</span>' : '<span class="badge badge-success">OK</span>']], p)}</div>`;
}

/* ============================================
   Users & Team Management Page
   ============================================ */
async function usersPage() {
  let rows = [];
  root().innerHTML = head('Team & Users', 'Manage staff accounts, access permissions, and roles.', `<button class="btn btn-primary" id="add-user">+ Add Team Member</button>`) +
    `<div id="user-stats"></div><div class="card" style="padding:0"><div id="user-table"></div></div>`;

  const draw = () => {
    $('#user-stats').innerHTML = cards(
      stat('Total Users', rows.length) +
      stat('Admins', rows.filter(r => r.role === 'admin').length) +
      stat('Managers', rows.filter(r => r.role === 'manager').length) +
      stat('Staff Members', rows.filter(r => r.role === 'staff').length)
    );

    $('#user-table').innerHTML = tbl([
      ['Name', r => `<b>${esc(r.name)}</b>`],
      ['Email', r => esc(r.email)],
      ['Role', r => `<span class="badge ${r.role === 'admin' ? 'badge-primary' : r.role === 'manager' ? 'badge-info' : 'badge-gray'}">${esc(r.role)}</span>`],
      ['Status', r => r.active == 1 ? '<span class="badge badge-success">Active</span>' : '<span class="badge badge-danger">Inactive</span>'],
      ['Created', r => esc(day(r.created_at))],
      ['Action', r => `<button class="btn btn-secondary btn-sm" data-edit="${r.id}">Edit</button> <button class="btn btn-danger btn-sm" data-del="${r.id}">Delete</button>`]
    ], rows);
  };

  const load = async () => {
    rows = await api('users.php');
    draw();
  };

  const userForm = r => {
    modal(r ? 'Edit User' : 'Add Team Member', `
      <div style="display:flex;flex-direction:column;gap:12px;">
        ${fld('Full Name *', `<input id="u-name" class="form-input" value="${esc(r ? r.name : '')}" required>`)}
        ${fld('Email Address *', `<input id="u-email" type="email" class="form-input" value="${esc(r ? r.email : '')}" required>`)}
        ${fld('Role *', `
          <select id="u-role" class="form-input form-select">
            <option value="staff"${r && r.role === 'staff' ? ' selected' : ''}>Staff (Sales & POS access)</option>
            <option value="manager"${r && r.role === 'manager' ? ' selected' : ''}>Manager (Inventory, Purchases, Reports)</option>
            <option value="admin"${r && r.role === 'admin' ? ' selected' : ''}>Admin (Full System Access)</option>
          </select>
        `)}
        ${fld(r ? 'New Password (leave blank to keep current)' : 'Password (min 8 chars) *', `<input id="u-pass" type="password" class="form-input" placeholder="${r ? '••••••••' : 'Password'}">`)}
        ${r ? `
          <div>
            <label class="form-label">Account Status</label>
            <select id="u-active" class="form-input form-select">
              <option value="1"${r.active == 1 ? ' selected' : ''}>Active</option>
              <option value="0"${r.active == 0 ? ' selected' : ''}>Inactive / Suspended</option>
            </select>
          </div>
        ` : ''}
      </div>
    `, 'Save User', async () => {
      const name = $('#u-name').value.trim();
      const email = $('#u-email').value.trim();
      const role = $('#u-role').value;
      const password = $('#u-pass').value;
      if (!name || !email) { Toast.error('Name and email are required', 'Validation Error'); return false; }
      if (!r && (!password || password.length < 8)) { Toast.error('Password must be at least 8 characters', 'Validation Error'); return false; }

      const body = { name, email, role, password };
      if (r) body.active = $('#u-active').value;

      await api('users.php' + (r ? '?id=' + r.id : ''), { method: r ? 'PUT' : 'POST', body });
      Toast.success('User updated successfully', 'Done');
      load();
    });
  };

  $('#add-user').onclick = () => userForm(null);
  $('#user-table').onclick = e => {
    const editBtn = e.target.closest('[data-edit]');
    const delBtn = e.target.closest('[data-del]');
    if (editBtn) userForm(rows.find(r => r.id == editBtn.dataset.edit));
    if (delBtn) {
      Modal.confirm({
        title: 'Delete Team Member', message: 'Are you sure? This user will no longer be able to log in.', type: 'danger', confirmText: 'Delete',
        onConfirm: () => api('users.php?id=' + delBtn.dataset.del, { method: 'DELETE' }).then(() => { Toast.success('User deleted', 'Done'); load(); }).catch(bad)
      });
    }
  };

  load().catch(bad);
}

/* ============================================
   Roles & Permissions Matrix Page
   ============================================ */
async function rolesPage() {
  root().innerHTML = head('Roles & Permissions', 'Access control matrix across system modules.') +
    `<div class="card" style="padding:0">
      <div style="overflow-x:auto;">
        <table class="data-table">
          <thead>
            <tr>
              <th>Module / Permission</th>
              <th style="text-align:center;"><span class="badge badge-primary">Admin</span></th>
              <th style="text-align:center;"><span class="badge badge-info">Manager</span></th>
              <th style="text-align:center;"><span class="badge badge-gray">Staff</span></th>
            </tr>
          </thead>
          <tbody>
            <tr><td><b>Dashboard Overview</b></td><td style="text-align:center;">✅ Full</td><td style="text-align:center;">✅ Full</td><td style="text-align:center;">✅ View Only</td></tr>
            <tr><td><b>Point of Sale (POS) & Sales</b></td><td style="text-align:center;">✅ Full</td><td style="text-align:center;">✅ Full</td><td style="text-align:center;">✅ Create & View</td></tr>
            <tr><td><b>Inventory & Product Catalog</b></td><td style="text-align:center;">✅ Create/Edit/Delete</td><td style="text-align:center;">✅ Create/Edit</td><td style="text-align:center;">✅ View Only</td></tr>
            <tr><td><b>Stock Adjustments</b></td><td style="text-align:center;">✅ Apply</td><td style="text-align:center;">✅ Apply</td><td style="text-align:center;">❌ No</td></tr>
            <tr><td><b>Purchases & Suppliers</b></td><td style="text-align:center;">✅ Full</td><td style="text-align:center;">✅ Full</td><td style="text-align:center;">❌ No</td></tr>
            <tr><td><b>Financials & Profit & Loss</b></td><td style="text-align:center;">✅ Full</td><td style="text-align:center;">✅ Full</td><td style="text-align:center;">❌ No</td></tr>
            <tr><td><b>Team & User Management</b></td><td style="text-align:center;">✅ Full</td><td style="text-align:center;">❌ No</td><td style="text-align:center;">❌ No</td></tr>
          </tbody>
        </table>
      </div>
    </div>`;
}

/* ============================================
   Profile Page
   ============================================ */
async function profilePage() {
  const u = await api('auth.php?action=me');
  root().innerHTML = `
    <div class="page-header">
      <div>
        <div class="breadcrumb"><a href="../dashboard.html">Home</a><span class="sep">/</span><span class="current">My Profile</span></div>
        <h1 class="page-title">My Profile</h1>
      </div>
    </div>

    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:20px;">
      <div class="card" style="padding:24px;text-align:center;">
        <div class="avatar avatar-lg w-20 h-20 text-[28px] mx-auto mb-4 bg-[var(--primary)] text-white flex items-center justify-center rounded-full font-bold">
          ${(u.name || 'U').split(' ').filter(Boolean).map(n => n[0]).join('').substring(0, 2).toUpperCase()}
        </div>
        <h2 style="font-size:18px;font-weight:700;margin:0;">${esc(u.name)}</h2>
        <div style="font-size:13px;color:var(--muted);margin-top:2px;">${esc(u.email)}</div>
        <div style="margin-top:12px;"><span class="badge badge-primary">${esc(u.role).toUpperCase()}</span></div>
      </div>

      <div class="card" style="padding:24px;">
        <h3 style="font-weight:700;margin-bottom:16px;">Update Information</h3>
        <form id="prof-form" style="display:flex;flex-direction:column;gap:14px;">
          ${fld('Full Name', `<input id="p-name" class="form-input" value="${esc(u.name)}" required>`)}
          ${fld('Email Address', `<input id="p-email" type="email" class="form-input" value="${esc(u.email)}" required>`)}
          <hr style="border:0;border-top:1px solid var(--border);margin:8px 0;">
          <h4 style="font-weight:600;font-size:14px;margin:0;">Change Password</h4>
          ${fld('Current Password', `<input id="p-cur-pw" type="password" class="form-input" placeholder="Current password">`)}
          ${fld('New Password (min 8 chars)', `<input id="p-new-pw" type="password" class="form-input" placeholder="New password">`)}
          <button type="submit" class="btn btn-primary" id="save-prof" style="align-self:flex-start;margin-top:8px;">Save Profile</button>
        </form>
      </div>
    </div>
  `;

  $('#prof-form').onsubmit = async (e) => {
    e.preventDefault();
    const name = $('#p-name').value.trim();
    const email = $('#p-email').value.trim();
    const current_password = $('#p-cur-pw').value;
    const new_password = $('#p-new-pw').value;

    const body = { name, email };
    if (new_password) {
      if (!current_password) return Toast.error('Enter your current password to set a new password', 'Error');
      body.current_password = current_password;
      body.new_password = new_password;
    }

    try {
      $('#save-prof').disabled = true;
      const res = await api('auth.php?action=profile', { method: 'POST', body });
      Toast.success('Profile updated successfully', 'Saved');
      window.CURRENT_USER = Object.assign(window.CURRENT_USER || {}, res);
      if (typeof initHeaderUser === 'function') initHeaderUser();
      $('#p-cur-pw').value = '';
      $('#p-new-pw').value = '';
    } catch (err) {
      bad(err);
    } finally {
      $('#save-prof').disabled = false;
    }
  };
}

/* ============================================
   Returns History Pages
   ============================================ */
async function returnsPage(kind) {
  const sale = kind === 'sale';
  const movements = await api('stock.php');
  const filtered = movements.filter(m => (sale ? m.type === 'sale' : m.type === 'purchase') || m.type === 'adjustment');

  root().innerHTML = head(sale ? 'Sales Returns & Adjustments' : 'Purchase Returns & Adjustments', 'Audit log of returned items and quantity deductions.') +
    `<div class="card" style="padding:0">
      ${tbl([
        ['Date', r => esc(day(r.created_at))],
        ['Product', r => `<b>${esc(r.name)}</b>${sub(esc(r.sku))}`],
        ['Type', r => `<span class="badge badge-info">${esc(r.type)}</span>`],
        ['Qty', r => `<b style="color:${r.qty < 0 ? 'var(--danger)' : 'var(--primary)'}">${r.qty > 0 ? '+' : ''}${r.qty}</b>`],
        ['Note', r => esc(r.note || '—')]
      ], filtered, 'No returns recorded yet.')}
    </div>`;
}

/* ============================================
   Point of Sale (POS)
   Markup shell for assets/js/pos.js, which owns the cart, the product grid
   and the sale submission. Mirrors the Invenza POS layout.
   ============================================ */
function posPage() {
  const QUICK = [10, 20, 50, 100];
  const line = (label, valueId, extra = '') => `
    <div style="display:flex;justify-content:space-between;align-items:center;padding:5px 0;font-size:13px">
      <span style="color:var(--muted)">${label}</span>${extra}
      <b id="${valueId}" style="font-weight:600"></b>
    </div>`;

  root().innerHTML = `
    <div class="page-header">
      <div>
        <h1 class="page-title">Point of Sale (POS)</h1>
        <p class="page-subtitle">Tap a product to add it to the cart, then take payment.</p>
      </div>
      <div class="page-header-actions">
        <span class="badge badge-success">Register #01 &middot; Active</span>
        <a href="sales.html" class="btn btn-secondary">Sales List</a>
      </div>
    </div>

    <div class="grid grid-cols-1 xl:grid-cols-[minmax(0,1fr)_380px] gap-4 items-start">

      <!-- Catalogue -->
      <div class="card" style="padding:16px">
        <div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:14px">
          <input id="pos-search" type="search" class="form-input" autocomplete="off"
                 placeholder="Search by name, SKU or category…" style="flex:1;min-width:200px">
          <select id="pos-category-filter" class="form-input form-select" style="width:auto;min-width:170px">
            <option value="all">All Categories</option>
          </select>
        </div>
        <div id="pos-product-grid" class="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-4 gap-3"></div>
      </div>

      <!-- Cart -->
      <div class="card" style="padding:0;display:flex;flex-direction:column">
        <div style="padding:14px 16px;border-bottom:1px solid var(--border);display:flex;justify-content:space-between;align-items:center">
          <div style="font-weight:700">Current Cart
            <span class="badge badge-info" id="pos-cart-count" style="margin-left:6px">0</span>
          </div>
          <button id="pos-clear-cart" class="btn btn-ghost btn-sm">Clear All</button>
        </div>

        <div style="padding:12px 16px;border-bottom:1px solid var(--border)">
          <label class="form-label">Customer</label>
          <select id="pos-customer" class="form-input form-select">
            <option value="">Walk-in Customer (Guest)</option>
          </select>
        </div>

        <div id="pos-cart-items" style="padding:0 16px;max-height:340px;overflow-y:auto"></div>

        <div style="padding:12px 16px;border-top:1px solid var(--border)">
          ${line('Subtotal', 'pos-subtotal')}
          <div style="display:flex;justify-content:space-between;align-items:center;padding:5px 0;font-size:13px">
            <span style="color:var(--muted)">Discount (%)</span>
            <input id="pos-discount-input" type="number" min="0" max="100" step="0.01" value="0"
                   class="form-input" style="width:90px;text-align:right">
          </div>
          <div style="display:flex;justify-content:space-between;align-items:center;padding:5px 0;font-size:13px">
            <span style="color:var(--muted)">Tax (%)</span>
            <input id="pos-tax-input" type="number" min="0" max="100" step="0.01" value="0"
                   class="form-input" style="width:90px;text-align:right">
          </div>
          ${line('Discount Amount', 'pos-discount')}
          ${line('Tax Amount', 'pos-tax')}
          <div style="display:flex;justify-content:space-between;align-items:center;padding:8px 0 0;margin-top:6px;border-top:1px solid var(--border)">
            <span style="font-weight:700">Payable Total</span>
            <b id="pos-total" style="font-size:18px;color:var(--primary)"></b>
          </div>
        </div>

        <div style="padding:12px 16px;border-top:1px solid var(--border)">
          <div style="display:flex;gap:6px;margin-bottom:10px">
            ${QUICK.map(q => `<button data-quick="${q}" class="btn btn-secondary btn-sm quick-amount-btn" style="flex:1">${window.CUR || '$'}${q}</button>`).join('')}
          </div>
          <label class="form-label">Tendered Cash (${window.CUR || '$'})</label>
          <input id="pos-paid-amount" type="number" min="0" step="0.01" class="form-input" placeholder="0.00">
          <div style="display:flex;justify-content:space-between;align-items:center;margin-top:10px">
            <span style="font-size:13px;color:var(--muted)">Change Due</span>
            <b id="pos-change" style="font-size:15px"></b>
          </div>
        </div>

        <div style="padding:14px 16px;border-top:1px solid var(--border)">
          <button id="pos-complete-btn" class="btn btn-primary btn-lg" style="width:100%">
            Complete Sale <span id="pos-total-label"></span>
          </button>
        </div>
      </div>
    </div>`;

  /* Quick-amount buttons add to the tendered cash. pos.js does not bind these. */
  root().querySelectorAll('[data-quick]').forEach(b => {
    b.onclick = () => {
      const el = document.getElementById('pos-paid-amount');
      if (!el) return;
      el.value = ((parseFloat(el.value) || 0) + Number(b.dataset.quick)).toFixed(2);
      if (typeof calculateTotals === 'function') calculateTotals();
    };
  });

  if (typeof initPOS === 'function') {
    initPOS().catch(bad);
  } else {
    Toast.error('The POS module did not load. Check that assets/js/pos.js is included on this page.', 'Error');
  }
}

/* ============================================
   Dashboard Overview
   ============================================ */
/* ============================================
   Dashboard Overview
   Mirrors the Invenza/Envato dashboard layout, but every figure comes
   from api/dashboard.php. Bars are real ratios, not decoration.
   ============================================ */
let _dashRange = 'mtd';
let _dashData  = null;

const clampPct = n => Math.max(0, Math.min(100, Number(n) || 0));
const int      = n => Math.round(Number(n) || 0).toLocaleString();

/**
 * Trend pill. A rise in cost is bad, so pass invert=true for cost.
 * null means the previous period was empty — there is no meaningful percentage.
 */
const trendPct = v => (v === null || v === undefined ? null : Math.min(999, Math.abs(Number(v) || 0)));
const trend = (v, invert = false) => {
  if (v === null || v === undefined) {
    return `<div class="trend-up" title="No trading in the previous period" style="opacity:.6">new</div>`;
  }
  const n = Number(v) || 0, up = n >= 0, good = invert ? !up : up;
  const arrow = up ? '↑' : '↓';
  const shown = Math.abs(n) > 999 ? `${arrow} 999%+` : `${arrow} ${Math.abs(n).toFixed(1)}%`;
  return `<div class="${good ? 'trend-up' : 'trend-down'}"${Math.abs(n) > 999 ? ' title="Capped display; previous period was very small"' : ''}>${shown}</div>`;
};

const niceDate = s => {
  const d = new Date(String(s || '').replace(' ', 'T'));
  return isNaN(d) ? esc(day(s)) : d.toLocaleDateString(undefined, {month: 'short', day: '2-digit', year: 'numeric'});
};

/** Payment state is derived from paid vs total — the sales table has no status column. */
const payBadge = r => (Number(r.paid) >= Number(r.total))
  ? '<span class="badge badge-success">Paid</span>'
  : (Number(r.paid) > 0 ? '<span class="badge badge-warning">Partial</span>'
                        : '<span class="badge badge-danger">Pending</span>');

const stockBadge = r => Number(r.stock) <= 0
  ? '<span class="badge badge-danger">Out of Stock</span>'
  : (Number(r.stock) <= Number(r.min_stock) * 0.5
      ? '<span class="badge badge-danger">Critical</span>'
      : '<span class="badge badge-warning">Low Stock</span>');

const thumb = (name, img, cls) => img
  ? `<img src="${esc(String(img).replace(/^\/+/, ''))}" alt="${esc(name)}" class="${cls}">`
  : `<div class="${cls} bg-slate-100 flex items-center justify-center text-[11px] font-bold text-[var(--muted)]">${esc(String(name || '?').slice(0, 2).toUpperCase())}</div>`;

const SVG = {
  home:    '<path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>',
  cal:     '<rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>',
  pulse:   '<path d="M22 12h-4l-3 9L9 3l-3 9H2"/>',
  down:    '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/>',
  cash:    '<line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>',
  up:      '<polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/>',
  dn:      '<polyline points="23 18 13.5 8.5 8.5 13.5 1 6"/><polyline points="17 18 23 18 23 12"/>',
  bars:    '<line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/>',
  box:     '<path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/>',
  clock:   '<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>',
  user:    '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/>',
  users:   '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
  truck:   '<rect x="1" y="3" width="15" height="13"/><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/>',
  alert:   '<path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>',
  bag:     '<path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 0 1-8 0"/>',
  wallet:  '<rect x="1" y="4" width="22" height="16" rx="2" ry="2"/><line x1="1" y1="10" x2="23" y2="10"/>',
};
const ic = (k, s = 16, w = 2.5, stroke = 'currentColor') =>
  `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="${stroke}" stroke-width="${w}" stroke-linecap="round" stroke-linejoin="round">${SVG[k]}</svg>`;

/** Card heading with an icon chip, matching the template's card-header. */
const cardHead = (icon, bg, title, subtitle = '', right = '') => `
  <div class="card-header">
    <div class="flex items-center gap-2">
      <div class="stat-card-icon ${bg} w-8 h-8 rounded-lg">${ic(icon, 16, 2.5, 'var(--primary)')}</div>
      <div>${subtitle ? `<h2 class="card-title">${title}</h2><p class="card-subtitle">${subtitle}</p>` : `<h2 class="card-title">${title}</h2>`}</div>
    </div>${right}
  </div>`;

/** Two-up metric tile used by Inventory Overview and No. of Users. */
const metric = (icon, bg, value, label) => `
  <div class="dash-metric-card flex-1">
    <div class="dash-metric-icon ${bg}">${ic(icon, 20, 2)}</div>
    <div class="dash-metric-value">${value}</div>
    <div class="dash-metric-label">${label}</div>
  </div>`;

/** Labelled progress row used by Stock Overview and Purchase Overview. */
const progRow = (label, value, pct, color, valueCls = '') => `
  <div class="dash-stock-item">
    <div class="flex items-center justify-between mb-2">
      <div class="dash-stock-info"><div class="dash-stock-dot" style="background:${color}"></div><span class="text-[13px] font-medium">${label}</span></div>
      <span class="text-[18px] font-bold ${valueCls}">${value}</span>
    </div>
    <div class="dash-progress-track"><div class="dash-progress-fill" style="width:${clampPct(pct)}%;background:${color}"></div></div>
  </div>`;

/** Download the dashboard payload as CSV — the Export button does real work. */
function exportDashboardCsv(d) {
  const rows = [
    ['Lush View Bar — Dashboard', d.range === 'ytd' ? 'Year to Date' : 'Month to Date', `${d.period.from} to ${d.period.to}`],
    [],
    ['Metric', 'Value', 'Change vs previous period (%)'],
    ['Total Sales (transactions)', d.sales_count, d.delta.sales_count],
    ['Revenue', d.revenue, d.delta.revenue],
    ['Cost', d.cost, d.delta.cost],
    ['Expenses', d.expenses, ''],
    ['Profit', d.profit, d.delta.profit],
    ['Qty in Hand', d.qty_in_hand, ''],
    ['Stock Value', d.stock_value, ''],
    ['Low Stock Items', d.low, ''],
    ['Out of Stock', d.out, ''],
    ['Item Groups', d.item_groups, ''],
    ['No. of Items', d.items, ''],
    ['Total Customers', d.customers, ''],
    ['Total Suppliers', d.suppliers, ''],
    ['No. of Purchases', d.purchases_count, ''],
    ['Purchase Cost', d.purchase_cost, ''],
  ];
  const csv = rows.map(r => r.map(c => `"${String(c ?? '').replace(/"/g, '""')}"`).join(',')).join('\r\n');
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([csv], {type: 'text/csv;charset=utf-8'}));
  a.download = `lushview-dashboard-${d.period.from}_to_${d.period.to}.csv`;
  a.click();
  URL.revokeObjectURL(a.href);
  Toast.success('Dashboard exported', 'CSV');
}

async function dashboard(range = _dashRange) {
  _dashRange = range;
  const d = await api(`dashboard.php?range=${encodeURIComponent(range)}`);
  _dashData = d;

  const who      = (window.CURRENT_USER && window.CURRENT_USER.name) ? window.CURRENT_USER.name.split(' ')[0] : 'back';
  const rev      = Number(d.revenue) || 0;
  const monthly  = (d.sales_series.monthly.values || []).map(Number);
  const yrTotal  = monthly.reduce((a, b) => a + b, 0) || 0;
  const yrPeak   = Math.max(1, ...monthly);
  const revenue  = rev || 0;

  const periodName = range === 'ytd' ? 'Year to Date' : 'Month to Date';

  root().innerHTML = `
    <!-- Welcome Banner -->
    <div class="welcome-banner animate-slideInUp">
      <div class="welcome-banner-content">
        <div class="welcome-banner-icon">${ic('home', 28, 2, 'white')}</div>
        <div>
          <h1 class="welcome-title">Welcome back, ${esc(who)}!</h1>
          <p class="welcome-subtitle">Here's what's happening with your inventory today. You have <strong>${int(d.low + d.out)} item${(d.low + d.out) === 1 ? '' : 's'}</strong> running low on stock.</p>
        </div>
      </div>
      <div class="welcome-actions">
        <button data-date-filter="mtd" class="btn-welcome-outline${range === 'mtd' ? ' active' : ''}" aria-label="Filter by month to date">${ic('cal', 14, 2)} Month to Date</button>
        <button data-date-filter="ytd" class="btn-welcome-outline${range === 'ytd' ? ' active' : ''}" aria-label="Filter by year to date">${ic('pulse', 14, 2)} Year to Date</button>
        <button class="btn-welcome-export" id="dash-export" aria-label="Export dashboard data">${ic('down', 14, 2.5)} Export</button>
      </div>
    </div>

    <!-- Row 1: Stats Cards -->
    <div class="page-section grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-3 sm:gap-4 md:gap-5">
      <div class="dash-stat-card animate-slideInUp stagger-1">
        <div class="dash-stat-top"><div class="dash-stat-icon icon-bg-success">${ic('cash', 22, 2)}</div>${trend(d.delta.sales_count)}</div>
        <div class="dash-stat-value"><span data-count="${int(d.sales_count).replace(/,/g, '')}">0</span></div>
        <div class="dash-stat-label">Total Sales</div>
        <div class="dash-stat-bar"><div class="dash-stat-bar-fill" style="width:${clampPct(yrTotal ? (revenue / yrTotal) * 100 : 0)}%;background:var(--primary)"></div></div>
      </div>
      <div class="dash-stat-card animate-slideInUp stagger-2">
        <div class="dash-stat-top"><div class="dash-stat-icon icon-bg-info">${ic('up', 22, 2)}</div>${trend(d.delta.revenue)}</div>
        <div class="dash-stat-value"><span data-count="${Math.round(revenue)}" data-prefix="${esc(CUR)}">0</span></div>
        <div class="dash-stat-label">Revenue</div>
        <div class="dash-stat-bar"><div class="dash-stat-bar-fill" style="width:${clampPct((revenue / yrPeak) * 100)}%;background:var(--info)"></div></div>
      </div>
      <div class="dash-stat-card animate-slideInUp stagger-3">
        <div class="dash-stat-top"><div class="dash-stat-icon icon-bg-danger">${ic('dn', 22, 2)}</div>${trend(d.delta.cost, true)}</div>
        <div class="dash-stat-value"><span data-count="${Math.round(d.cost)}" data-prefix="${esc(CUR)}">0</span></div>
        <div class="dash-stat-label">Cost</div>
        <div class="dash-stat-bar"><div class="dash-stat-bar-fill" style="width:${clampPct(revenue ? (d.cost / revenue) * 100 : 0)}%;background:var(--danger)"></div></div>
      </div>
      <div class="dash-stat-card animate-slideInUp stagger-4">
        <div class="dash-stat-top"><div class="dash-stat-icon icon-bg-warning">${ic('bars', 22, 2)}</div>${trend(d.delta.profit)}</div>
        <div class="dash-stat-value dash-stat-profit"><span data-count="${Math.round(d.profit)}" data-prefix="${esc(CUR)}">0</span></div>
        <div class="dash-stat-label">Profit</div>
        <div class="dash-stat-bar"><div class="dash-stat-bar-fill" style="width:${clampPct(revenue ? (d.profit / revenue) * 100 : 0)}%;background:var(--warning)"></div></div>
      </div>
    </div>

    <!-- Row 2: Sales Chart + Revenue Breakdown -->
    <div class="page-section grid grid-cols-1 lg:grid-cols-3 gap-4 md:gap-5">
      <div class="card lg:col-span-2 animate-slideInUp stagger-3">
        ${cardHead('pulse', 'icon-bg-primary', 'Sales Statistics', `${periodName} revenue overview`, `
          <div class="flex gap-1.5">
            <button data-sales-period="daily" class="btn btn-secondary btn-sm" aria-label="View daily sales">Daily</button>
            <button data-sales-period="weekly" class="btn btn-secondary btn-sm" aria-label="View weekly sales">Weekly</button>
            <button data-sales-period="monthly" class="btn btn-primary btn-sm" aria-label="View monthly sales">Monthly</button>
          </div>`)}
        <div class="flex items-baseline gap-3 mb-5">
          <div class="dash-chart-total">${money(revenue)}</div>
          ${d.delta.revenue === null || d.delta.revenue === undefined
            ? `<span style="font-size:12px;color:var(--muted)">no trading in the previous period</span>`
            : `<span class="${d.delta.revenue >= 0 ? 'trend-up' : 'trend-down'}" style="font-size:12px">${d.delta.revenue >= 0 ? '↑' : '↓'} ${trendPct(d.delta.revenue).toFixed(1)}%${Math.abs(d.delta.revenue) > 999 ? '+' : ''} vs previous period</span>`}
        </div>
        <div class="chart-container h-[240px]"><canvas id="salesChart"></canvas></div>
      </div>

      <div class="card animate-slideInUp stagger-4">
        ${cardHead('cash', 'icon-bg-success', 'Revenue Breakdown')}
        <div class="flex flex-col gap-3">
          ${[['Total Sales', `${int(d.sales_count)} transactions`, money(d.sales_count ? revenue / 1 : 0), 'var(--primary)', ''],
             ['Revenue', 'Net of discounts', money(revenue), 'var(--info)', ''],
             ['Cost', 'Cost of goods sold', money(d.cost), 'var(--danger)', ''],
             ['Profit', revenue ? `Net margin ${(d.profit / revenue * 100).toFixed(1)}%` : 'Net margin —', money(d.profit), 'var(--warning)', 'dash-stat-profit']]
            .map(([l, desc, amt, dot, cls]) => `
            <div class="dash-revenue-item">
              <div class="flex items-center gap-3">
                <div class="dash-revenue-dot" style="background:${dot}"></div>
                <div><div class="dash-revenue-label">${l}</div><div class="dash-revenue-desc">${desc}</div></div>
              </div>
              <div class="dash-revenue-amount ${cls}">${amt}</div>
            </div>`).join('')}
        </div>
      </div>
    </div>

    <!-- Row 3: Inventory + Users + Stock -->
    <div class="page-section grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-5">
      <div class="card animate-slideInUp stagger-2">
        ${cardHead('box', 'icon-bg-primary', 'Inventory Overview')}
        <div class="flex gap-4">
          ${metric('box', 'icon-bg-primary', int(d.qty_in_hand), 'Qty in Hand')}
          ${metric('wallet', 'icon-bg-info', money(d.stock_value), 'Stock Value')}
        </div>
      </div>

      <div class="card animate-slideInUp stagger-3">
        ${cardHead('users', 'icon-bg-info', 'No. of Users')}
        <div class="flex gap-4">
          ${metric('user', 'icon-bg-info', int(d.customers), 'Total Customers')}
          ${metric('truck', 'icon-bg-purple', int(d.suppliers), 'Total Suppliers')}
        </div>
      </div>

      <div class="card animate-slideInUp stagger-4">
        ${cardHead('alert', 'icon-bg-danger', 'Stock Overview')}
        <div class="flex flex-col gap-3">
          ${progRow('Low Stock Items', String(d.low).padStart(2, '0'), d.items ? (d.low / d.items) * 100 : 0, 'var(--danger)', 'text-[var(--danger)]')}
          ${progRow('Out of Stock', String(d.out).padStart(2, '0'), d.items ? (d.out / d.items) * 100 : 0, 'var(--warning)')}
          ${progRow('Item Groups', String(d.item_groups).padStart(2, '0'), d.items ? (d.item_groups / d.items) * 100 : 0, 'var(--info)')}
          ${progRow('No. of Items', int(d.items), 100, 'var(--primary)')}
        </div>
      </div>
    </div>

    <!-- Row 4: Customer Chart + Purchase Overview -->
    <div class="page-section grid grid-cols-1 lg:grid-cols-3 gap-4 md:gap-5">
      <div class="card lg:col-span-2 animate-slideInUp stagger-3">
        ${cardHead('users', 'icon-bg-info', 'Customer Statistics', 'New customers over time', `
          <div class="flex gap-1.5">
            <button data-customer-period="weekly" class="btn btn-secondary btn-sm" aria-label="View weekly customers">Weekly</button>
            <button data-customer-period="monthly" class="btn btn-primary btn-sm" aria-label="View monthly customers">Monthly</button>
          </div>`)}
        <div class="flex items-baseline gap-3 mb-5">
          <div class="dash-chart-total">${int(d.customer_series.monthly.values.reduce((a, b) => a + Number(b), 0))}</div>
          <span class="trend-up" style="font-size:12px">new customers in the last 12 months</span>
        </div>
        <div class="chart-container h-[240px]"><canvas id="customerChart"></canvas></div>
      </div>

      <div class="card animate-slideInUp stagger-4">
        ${cardHead('bag', 'icon-bg-purple', 'Purchase Overview')}
        <div class="flex flex-col gap-3">
          ${progRow('No. of Purchases', int(d.purchases_count), d.purchases_count ? 100 : 0, '#8B5CF6')}
          ${progRow('Purchase Cost', money(d.purchase_cost), revenue ? (d.purchase_cost / revenue) * 100 : 0, 'var(--warning)')}
          ${progRow('Paid to Suppliers', money(d.purchase_paid), d.purchase_cost ? (d.purchase_paid / d.purchase_cost) * 100 : 0, 'var(--success)')}
          ${progRow('Outstanding', money(d.purchase_cost - d.purchase_paid), d.purchase_cost ? ((d.purchase_cost - d.purchase_paid) / d.purchase_cost) * 100 : 0, 'var(--danger)', 'text-[var(--danger)]')}
        </div>
      </div>
    </div>

    <!-- Row 5: Recent Sales -->
    <div class="page-section">
      <div class="card animate-slideInUp stagger-2" style="padding:0">
        ${cardHead('cash', 'icon-bg-primary', 'Recent Sales', 'Latest transactions', `
          <a href="sales/sales.html" class="btn btn-secondary btn-sm">View All Sales</a>`)}
        <table class="data-table">
          <caption class="sr-only">Recent sales transactions</caption>
          <thead><tr><th>Invoice</th><th>Customer</th><th>Date</th><th>Amount</th><th>Payment</th><th>Status</th><th>Action</th></tr></thead>
          <tbody>
            ${d.recent.length ? d.recent.map(r => `
              <tr>
                <td><a href="invoices/invoice-details.html?id=${r.id}" class="text-[13px] font-semibold text-[var(--primary)] no-underline">${esc(r.invoice_no)}</a></td>
                <td><span class="text-[13px] font-medium text-[var(--text)]">${esc(r.customer || 'Walk-in')}</span></td>
                <td class="text-[13px] text-[var(--muted)]">${niceDate(r.created_at)}</td>
                <td class="text-[13px] font-semibold text-[var(--text)]">${money(r.total)}</td>
                <td class="text-[13px] text-[var(--muted)]">${esc(r.payment_method || '—')}</td>
                <td>${payBadge(r)}</td>
                <td><a href="invoices/invoice-details.html?id=${r.id}" class="btn btn-secondary btn-sm" aria-label="View invoice ${esc(r.invoice_no)}">View</a></td>
              </tr>`).join('')
            : `<tr><td colspan="7" style="padding:40px;text-align:center;color:var(--muted)">No sales yet. Record one from the POS to populate this table.</td></tr>`}
          </tbody>
        </table>
      </div>
    </div>

    <!-- Row 6: Low Stock Products -->
    <div class="page-section">
      <div class="card animate-slideInUp stagger-3" style="padding:0">
        ${cardHead('alert', 'icon-bg-danger', 'Low Stock Products', `${d.low_items.length} item${d.low_items.length === 1 ? '' : 's'} requiring restocking`, `
          <a href="inventory/products.html" class="btn btn-secondary btn-sm">View All</a>`)}
        <table class="data-table">
          <caption class="sr-only">Products with low stock levels</caption>
          <thead><tr><th>Product</th><th>SKU</th><th>Current Stock</th><th>Min Stock</th><th>Status</th><th>Action</th></tr></thead>
          <tbody>
            ${d.low_items.length ? d.low_items.map(r => `
              <tr>
                <td><div class="flex items-center gap-2.5">${thumb(r.name, r.image, 'w-9 h-9 rounded-[10px] object-cover')}<span class="text-[13px] font-semibold text-[var(--text)]">${esc(r.name)}</span></div></td>
                <td class="text-xs text-[var(--muted)] font-mono">${esc(r.sku)}</td>
                <td class="text-sm font-bold text-[var(--danger)]">${r.stock}</td>
                <td class="text-[13px] text-[var(--muted)]">${r.min_stock}</td>
                <td>${stockBadge(r)}</td>
                <td><a href="purchases/add-purchase.html" class="btn btn-outline btn-sm" aria-label="Reorder ${esc(r.name)}">Reorder</a></td>
              </tr>`).join('')
            : `<tr><td colspan="6" style="padding:40px;text-align:center;color:var(--muted)">All stocked up — nothing below minimum levels.</td></tr>`}
          </tbody>
        </table>
      </div>
    </div>`;

  /* Wire the interactive pieces now that the markup exists. */
  const ex = document.getElementById('dash-export');
  if (ex) ex.onclick = () => exportDashboardCsv(d);

  window.onDashboardRangeChange = r => { if (r !== _dashRange) dashboard(r).catch(bad); };

  if (typeof initDashboard === 'function') {
    initDashboard({
      sales: d.sales_series,
      customers: d.customer_series,
      salesPeriod: 'monthly',
      customerPeriod: 'monthly'
    });
  } else {
    animateCounters();
  }
}

/* ============================================
   Page Router Dispatcher
   ============================================ */
document.addEventListener('DOMContentLoaded', () => setTimeout(async () => {
  const k = window.PAGE_KIND; if (!k || !root()) return;
  try {
    if (k.startsWith('crud:')) await crudPage(k.slice(5));
    else await ({
      stock: stockPage,
      sale: posPage,
      pos: posPage,
      purchase: () => docPage('purchase'),
      sales: () => salesList(false),
      'rpt-sales': () => salesList(true),
      purchases: () => purchasesList(false),
      'rpt-purchases': () => purchasesList(true),
      'rpt-inv': inventoryReport,
      'rpt-pl': profitAndLossReport,
      'rpt-customers': customersReport,
      'rpt-suppliers': suppliersReport,
      invoices: invoicesListPage,
      'invoice-details': invoiceDetailsPage,
      'product-details': productDetailsPage,
      users: usersPage,
      roles: rolesPage,
      profile: profilePage,
      'sales-returns': () => returnsPage('sale'),
      'purchase-returns': () => returnsPage('purchase'),
      dashboard
    }[k])();
  } catch (e) { bad(e); }
}, 300));
