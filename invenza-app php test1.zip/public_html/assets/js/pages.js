'use strict';
/* Live pages for Invenza. Edit CUR / BIZ below. */
window.CUR = window.CUR || 'GH₵';
window.BIZ = window.BIZ || 'Your Business Name';
const CUR = window.CUR, BIZ = window.BIZ;
const money = n => CUR + (Number(n) || 0).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2});
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const $ = (s, r = document) => r.querySelector(s);
const root = () => document.getElementById('app-root');
const bad = e => Toast.error(e.message || String(e), 'Error');
const day = s => String(s || '').slice(0, 10);
const today = () => new Date().toISOString().slice(0, 10);
const sub = t => `<div style="color:var(--muted);font-size:12px">${t}</div>`;
const head = (t, s, btn = '') => `<div class="page-header"><div><h1 class="page-title">${t}</h1><p class="page-subtitle">${s}</p></div><div class="page-header-actions">${btn}</div></div>`;
const card = (t, b) => `<div class="card" style="padding:18px"><h3 style="font-weight:700;margin-bottom:12px">${t}</h3>${b}</div>`;
const stat = (l, v, n = '') => `<div class="card" style="padding:18px"><div style="color:var(--muted);font-size:12px;font-weight:600">${l}</div><div style="font-size:24px;font-weight:700;margin-top:6px">${v}</div><div style="font-size:12px;color:var(--muted);margin-top:2px">${n}</div></div>`;
const cards = h => `<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:16px;margin-bottom:20px">${h}</div>`;
const two = h => `<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:16px">${h}</div>`;
const fld = (l, h) => `<div><label class="form-label">${l}</label>${h}</div>`;
const row = h => `<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:14px;margin-bottom:16px">${h}</div>`;

function tbl(cols, rows, empty = 'Nothing here yet.') {
  if (!rows.length) return `<div style="padding:40px;text-align:center;color:var(--muted)">${empty}</div>`;
  return `<div style="overflow-x:auto"><table class="data-table"><thead><tr>${cols.map(c => `<th>${c[0]}</th>`).join('')}</tr></thead><tbody>${rows.map(r => `<tr>${cols.map(c => `<td>${c[1](r)}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;
}
function modal(title, body, label, onSave) {
  Modal.show({title, size: 'md', body, footer: `<button class="btn btn-secondary" onclick="document.querySelector('.modal-backdrop')?.remove()">Close</button>${onSave ? `<button class="btn btn-primary" id="m-save">${label}</button>` : ''}`});
  setTimeout(() => { const b = $('#m-save'); if (b) b.onclick = async () => { b.disabled = true; try { if (await onSave() !== false) document.querySelector('.modal-backdrop')?.remove(); } catch (e) { bad(e); } b.disabled = false; }; }, 30);
}

/* ---------- Generic CRUD pages ---------- */
const nameCol = ['Name', r => `<b>${esc(r.name)}</b>`], created = ['Added', r => esc(day(r.created_at))];
const party = (one) => ({one, f: [['name','Name','text',1],['company','Company'],['email','Email','email'],['phone','Phone'],['city','City'],['address','Address']],
  c: [[one, r => `<b>${esc(r.name)}</b>${sub(esc(r.company || ''))}`], ['Contact', r => `${esc(r.email || '')}${sub(esc(r.phone || ''))}`], ['City', r => esc(r.city || '')]]});
const CRUDS = {
  categories: {title: 'Categories', s: 'Group your products.', one: 'Category', f: [['name','Name','text',1]], c: [nameCol, created]},
  brands: {title: 'Brands', s: 'Product brands.', one: 'Brand', f: [['name','Name','text',1]], c: [nameCol, created]},
  units: {title: 'Units', s: 'Units of measure (Piece, Box, Kg...).', one: 'Unit', f: [['name','Name','text',1]], c: [nameCol, created]},
  customers: {title: 'Customers', s: 'People you sell to.', ...party('Customer')},
  suppliers: {title: 'Suppliers', s: 'People you buy from.', ...party('Supplier')},
  expenses: {title: 'Expenses', s: 'Running costs (rent, transport, salaries...).', one: 'Expense',
    f: [['title','Title','text',1],['category','Category'],['amount','Amount','number',1],['expense_date','Date','date'],['note','Note']],
    c: [['Title', r => `<b>${esc(r.title)}</b>${sub(esc(r.note || ''))}`], ['Category', r => esc(r.category || '')], ['Amount', r => money(r.amount)], ['Date', r => esc(r.expense_date || '')]]},
};
async function crudPage(name) {
  const C = CRUDS[name]; let rows = [];
  root().innerHTML = head(C.title, C.s, `<button class="btn btn-primary" id="add">+ Add ${C.one}</button>`) +
    `<div class="card" style="padding:0"><div style="padding:14px"><input id="q" class="form-input" placeholder="Search..."></div><div id="t"></div></div>`;
  const draw = () => {
    const q = $('#q').value.toLowerCase(), list = rows.filter(r => JSON.stringify(Object.values(r)).toLowerCase().includes(q));
    $('#t').innerHTML = tbl([...C.c, ['', r => `<button class="btn btn-secondary btn-sm" data-e="${r.id}">Edit</button> <button class="btn btn-danger btn-sm" data-d="${r.id}">Delete</button>`]], list);
  };
  const load = async () => { rows = await api('crud.php?e=' + name); draw(); };
  const form = r => {
    modal((r ? 'Edit ' : 'Add ') + C.one,
      `<div style="display:flex;flex-direction:column;gap:12px">${C.f.map(([k, l, t = 'text', req]) => fld(l + (req ? ' *' : ''), `<input class="form-input" data-k="${k}" type="${t}" ${t === 'number' ? 'step="0.01" min="0"' : ''} value="${esc(r ? r[k] : (t === 'date' ? today() : ''))}">`)).join('')}</div>`,
      'Save', async () => {
        const body = {}; document.querySelectorAll('.modal-body [data-k]').forEach(i => body[i.dataset.k] = i.value);
        await api('crud.php?e=' + name + (r ? '&id=' + r.id : ''), {method: r ? 'PUT' : 'POST', body});
        Toast.success(C.one + ' saved', 'Done'); load();
      });
  };
  $('#add').onclick = () => form(null); $('#q').oninput = draw;
  $('#t').onclick = ev => {
    const e = ev.target.closest('[data-e]'), d = ev.target.closest('[data-d]');
    if (e) form(rows.find(r => r.id == e.dataset.e));
    if (d) Modal.confirm({title: 'Delete ' + C.one, message: 'This cannot be undone.', type: 'danger', confirmText: 'Delete',
      onConfirm: () => api('crud.php?e=' + name + '&id=' + d.dataset.d, {method: 'DELETE'}).then(() => { Toast.success('Deleted', 'Done'); load(); }).catch(bad)});
  };
  try { await load(); } catch (e) { bad(e); }
}

/* ---------- Stock adjustment ---------- */
async function stockPage() {
  let prods = await api('products.php');
  const opts = () => prods.map(p => `<option value="${p.id}">${esc(p.name)} (${esc(p.sku)}) — ${p.stock} in stock</option>`).join('');
  root().innerHTML = head('Stock Adjustment', 'Correct stock counts. Every change is logged below.') +
    `<div class="card" style="padding:18px;margin-bottom:20px">${row(
      fld('Product', `<select id="sp" class="form-input form-select">${opts()}</select>`) +
      fld('Action', `<select id="st" class="form-input form-select"><option value="add">Add stock</option><option value="remove">Remove stock</option></select>`) +
      fld('Quantity', `<input id="sq" type="number" min="0" step="any" class="form-input">`) +
      fld('Reason', `<input id="sn" class="form-input" placeholder="e.g. damaged, recount">`))}
    <button class="btn btn-primary" id="go">Apply adjustment</button></div><div class="card" id="mv" style="padding:0"></div>`;
  const load = async () => {
    const m = await api('stock.php');
    $('#mv').innerHTML = tbl([['Date', r => esc(day(r.created_at))], ['Product', r => `<b>${esc(r.name)}</b>${sub(esc(r.sku))}`], ['Type', r => `<span class="badge badge-info">${esc(r.type)}</span>`],
      ['Qty', r => `<b style="color:${r.qty < 0 ? 'var(--danger)' : 'var(--primary)'}">${r.qty > 0 ? '+' : ''}${r.qty}</b>`], ['Note', r => esc(r.note || '')]], m, 'No movements yet.');
  };
  $('#go').onclick = async () => {
    try {
      await api('stock.php', {method: 'POST', body: {product_id: $('#sp').value, type: $('#st').value, qty: $('#sq').value, note: $('#sn').value}});
      Toast.success('Stock updated', 'Done'); $('#sq').value = ''; $('#sn').value = '';
      prods = await api('products.php'); const v = $('#sp').value; $('#sp').innerHTML = opts(); $('#sp').value = v; load();
    } catch (e) { bad(e); }
  };
  load().catch(bad);
}

/* ---------- Invoice ---------- */
const invHTML = s => `<div style="font-family:sans-serif;max-width:560px;margin:auto;color:#111"><h2 style="margin:0">${esc(BIZ)}</h2>
<p style="color:#666;margin:2px 0 14px">Invoice ${esc(s.invoice_no)} · ${esc(day(s.created_at))}<br>Customer: ${esc(s.customer || 'Walk-in')}</p>
<table style="width:100%;border-collapse:collapse;font-size:14px"><tr style="border-bottom:1px solid #ccc;text-align:left"><th>Item</th><th>Qty</th><th>Price</th><th style="text-align:right">Total</th></tr>
${s.items.map(i => `<tr><td>${esc(i.name)}</td><td>${i.qty}</td><td>${money(i.price)}</td><td style="text-align:right">${money(i.qty * i.price)}</td></tr>`).join('')}</table><hr>
<div style="text-align:right;font-size:14px">Subtotal: ${money(s.subtotal)}<br>Discount: ${money(s.discount)}<br>Tax (${s.tax_percent}%): ${money(s.tax)}<br><b style="font-size:17px">Total: ${money(s.total)}</b><br>Paid: ${money(s.paid)} (${esc(s.payment_method)})</div></div>`;
async function showInvoice(id) {
  const s = await api('sales.php?id=' + id), html = invHTML(s);
  modal('Invoice ' + s.invoice_no, html, 'Print', () => {
    const w = window.open('', '_blank'); w.document.write('<title>' + esc(s.invoice_no) + '</title>' + html); w.document.close(); w.focus(); w.print(); return false;
  });
}

/* ---------- New sale / new purchase ---------- */
async function docPage(kind) {
  const sale = kind === 'sale';
  const [prods, parties] = await Promise.all([api('products.php'), api('crud.php?e=' + (sale ? 'customers' : 'suppliers'))]);
  const P = prods.filter(p => p.status === 'Active'); let L = [{}], paidEdited = false;
  root().innerHTML = head(sale ? 'New Sale' : 'New Purchase', sale ? 'Scan or pick products, then complete the sale.' : 'Receive stock from a supplier.') +
    `<div class="card" style="padding:20px">${row(
      fld(sale ? 'Customer' : 'Supplier', `<select id="party" class="form-input form-select"><option value="">${sale ? 'Walk-in customer' : '— select supplier —'}</option>${parties.map(p => `<option value="${p.id}">${esc(p.name)}</option>`).join('')}</select>`) +
      (sale ? fld('Payment method', `<select id="pay" class="form-input form-select"><option>Cash</option><option>Mobile Money</option><option>Card</option><option>Credit</option></select>`)
            : fld('Date', `<input id="pdate" type="date" class="form-input" value="${today()}">`) + fld('Reference', `<input id="pref" class="form-input" placeholder="Supplier invoice no.">`)))}
    ${sale ? `<input id="scan" class="form-input" placeholder="Scan barcode or type SKU, then press Enter" style="margin-bottom:12px">` : ''}
    <div id="lines" style="overflow-x:auto"></div>
    <button class="btn btn-secondary btn-sm" id="addl" style="margin:10px 0 18px">+ Add line</button>
    <div style="display:flex;justify-content:flex-end"><div style="min-width:290px;display:flex;flex-direction:column;gap:8px">
      ${sale ? `<div>Subtotal: <b id="t1"></b></div><div style="display:flex;gap:8px;align-items:center">Discount (${CUR}) <input id="disc" type="number" min="0" step="0.01" value="0" class="form-input" style="width:110px"></div>
      <div style="display:flex;gap:8px;align-items:center">Tax % <input id="tax" type="number" min="0" step="0.01" value="0" class="form-input" style="width:110px"></div>` : ''}
      <div style="font-size:18px">Total: <b id="t2"></b></div>
      <div style="display:flex;gap:8px;align-items:center">Amount paid <input id="paid" type="number" min="0" step="0.01" class="form-input" style="width:130px"></div></div></div>
    <div style="display:flex;justify-content:flex-end;margin-top:16px"><button class="btn btn-primary btn-lg" id="go">${sale ? 'Complete sale' : 'Save purchase'}</button></div></div>`;
  const qty = l => l.qty ?? 1;
  const calc = () => {
    const s = L.reduce((a, l) => a + qty(l) * (+l.price || 0), 0), d = sale ? +$('#disc').value || 0 : 0, t = sale ? +$('#tax').value || 0 : 0;
    const total = Math.max(0, s - d) * (1 + t / 100);
    if (sale) $('#t1').textContent = money(s); $('#t2').textContent = money(total);
    if (!paidEdited) $('#paid').value = total.toFixed(2);
  };
  const draw = () => {
    $('#lines').innerHTML = `<table class="data-table"><thead><tr><th>Product</th><th style="width:100px">Qty</th><th style="width:130px">${sale ? 'Price' : 'Cost'}</th><th style="width:120px">Total</th><th></th></tr></thead><tbody>${L.map((l, i) =>
      `<tr><td><select data-i="${i}" data-k="product_id" class="form-input form-select"><option value="">— choose product —</option>${P.map(p => `<option value="${p.id}"${l.product_id == p.id ? ' selected' : ''}>${esc(p.name)} (${esc(p.sku)})${sale ? ' · ' + p.stock + ' in stock' : ''}</option>`).join('')}</select></td>
      <td><input data-i="${i}" data-k="qty" type="number" min="0" step="any" class="form-input" value="${qty(l)}"></td>
      <td><input data-i="${i}" data-k="price" type="number" min="0" step="0.01" class="form-input" value="${l.price ?? ''}"></td>
      <td id="lt${i}">${money(qty(l) * (+l.price || 0))}</td><td><button class="btn btn-ghost btn-sm" data-rm="${i}">✕</button></td></tr>`).join('')}</tbody></table>`;
    calc();
  };
  const L$ = $('#lines');
  L$.onchange = e => { const t = e.target; if (t.dataset.k !== 'product_id') return; const l = L[t.dataset.i], p = P.find(x => x.id == t.value);
    l.product_id = t.value; l.price = p ? (sale ? p.sellingPrice : p.purchasePrice) : undefined; draw(); };
  L$.oninput = e => { const t = e.target, i = t.dataset.i; if (!i || t.dataset.k === 'product_id') return;
    L[i][t.dataset.k] = t.value === '' ? undefined : +t.value; $('#lt' + i).textContent = money(qty(L[i]) * (+L[i].price || 0)); calc(); };
  L$.onclick = e => { const b = e.target.closest('[data-rm]'); if (b) { L.splice(b.dataset.rm, 1); if (!L.length) L = [{}]; draw(); } };
  $('#addl').onclick = () => { L.push({}); draw(); };
  ['disc', 'tax'].forEach(i => $('#' + i) && ($('#' + i).oninput = calc));
  $('#paid').oninput = () => paidEdited = true;
  if (sale) $('#scan').onkeydown = e => {
    if (e.key !== 'Enter') return; e.preventDefault();
    const v = e.target.value.trim().toLowerCase(), p = P.find(x => (x.sku || '').toLowerCase() === v || (x.barcode || '').toLowerCase() === v);
    if (!p) return Toast.warning('No product with that SKU / barcode', 'Not found');
    const ex = L.find(l => l.product_id == p.id);
    if (ex) ex.qty = qty(ex) + 1; else { const blank = L.find(l => !l.product_id); const n = {product_id: String(p.id), price: p.sellingPrice};
      if (blank) Object.assign(blank, n); else L.push(n); }
    e.target.value = ''; draw();
  };
  $('#go').onclick = async () => {
    const items = L.filter(l => l.product_id).map(l => ({product_id: +l.product_id, qty: qty(l), [sale ? 'price' : 'cost']: l.price}));
    if (!items.length) return Toast.warning('Add at least one product', 'Nothing to save');
    const body = sale ? {customer_id: $('#party').value, payment_method: $('#pay').value, discount: $('#disc').value, tax_percent: $('#tax').value, paid: $('#paid').value, items}
                      : {supplier_id: $('#party').value, purchase_date: $('#pdate').value, ref: $('#pref').value, paid: $('#paid').value, items};
    $('#go').disabled = true;
    try {
      const r = await api(sale ? 'sales.php' : 'purchases.php', {method: 'POST', body});
      Toast.success(sale ? 'Sale completed' : 'Purchase saved — stock updated', 'Done');
      if (sale) { await docPage('sale'); showInvoice(r.id); } else location.href = 'purchases.html';
    } catch (e) { bad(e); $('#go').disabled = false; }
  };
  draw();
}

/* ---------- Lists & reports ---------- */
async function salesList(report) {
  root().innerHTML = head(report ? 'Sales Report' : 'Sales', report ? 'Filter by date and see totals.' : 'All completed sales.', report ? '' : `<a class="btn btn-primary" href="add-sale.html">+ New Sale</a>`) +
    (report ? `<div class="card" style="padding:14px;margin-bottom:16px;display:flex;gap:12px;align-items:end;flex-wrap:wrap"><div>${fld('From', `<input id="from" type="date" class="form-input" value="${today().slice(0, 8)}01">`)}</div><div>${fld('To', `<input id="to" type="date" class="form-input" value="${today()}">`)}</div><button class="btn btn-primary" id="run">Run</button></div><div id="sum"></div>` : '') +
    `<div class="card" id="t" style="padding:0"></div>`;
  const load = async () => {
    const rows = await api('sales.php' + (report ? `?from=${$('#from').value}&to=${$('#to').value}` : ''));
    if (report) $('#sum').innerHTML = cards(stat('Sales', rows.length) + stat('Revenue', money(rows.reduce((a, r) => a + r.total, 0))) + stat('Collected', money(rows.reduce((a, r) => a + r.paid, 0))) + stat('Outstanding', money(rows.reduce((a, r) => a + r.total - r.paid, 0))));
    $('#t').innerHTML = tbl([['Invoice', r => `<b>${esc(r.invoice_no)}</b>`], ['Date', r => esc(day(r.created_at))], ['Customer', r => esc(r.customer || 'Walk-in')], ['Payment', r => esc(r.payment_method)],
      ['Total', r => money(r.total)], ['Status', r => r.paid >= r.total ? '<span class="badge badge-success">Paid</span>' : '<span class="badge badge-warning">Owing ' + money(r.total - r.paid) + '</span>'],
      ['', r => `<button class="btn btn-secondary btn-sm" data-inv="${r.id}">Invoice</button>`]], rows, 'No sales yet.');
  };
  $('#t').onclick = e => { const b = e.target.closest('[data-inv]'); if (b) showInvoice(b.dataset.inv).catch(bad); };
  if (report) $('#run').onclick = () => load().catch(bad);
  load().catch(bad);
}
async function purchasesList() {
  const rows = await api('purchases.php');
  root().innerHTML = head('Purchases', 'Stock received from suppliers.', `<a class="btn btn-primary" href="add-purchase.html">+ New Purchase</a>`) +
    `<div class="card" style="padding:0">${tbl([['Date', r => esc(r.purchase_date || day(r.created_at))], ['Reference', r => esc(r.ref || '#' + r.id)], ['Supplier', r => esc(r.supplier || '—')], ['Total', r => money(r.total)],
      ['Status', r => r.paid >= r.total ? '<span class="badge badge-success">Paid</span>' : '<span class="badge badge-warning">Owing ' + money(r.total - r.paid) + '</span>']], rows, 'No purchases yet.')}</div>`;
}
async function inventoryReport() {
  const p = await api('products.php');
  const cost = p.reduce((a, x) => a + x.stock * x.purchasePrice, 0), retail = p.reduce((a, x) => a + x.stock * x.sellingPrice, 0);
  root().innerHTML = head('Inventory Report', 'Current stock and its value.') +
    cards(stat('Units in stock', p.reduce((a, x) => a + x.stock, 0)) + stat('Value at cost', money(cost)) + stat('Value at retail', money(retail)) + stat('Potential profit', money(retail - cost))) +
    `<div class="card" style="padding:0">${tbl([['Product', r => `<b>${esc(r.name)}</b>${sub(esc(r.sku))}`], ['Category', r => esc(r.category)], ['Stock', r => r.stock], ['Min', r => r.minStock],
      ['Cost value', r => money(r.stock * r.purchasePrice)], ['Retail value', r => money(r.stock * r.sellingPrice)],
      ['Status', r => r.stock <= 0 ? '<span class="badge badge-danger">Out</span>' : r.stock <= r.minStock ? '<span class="badge badge-warning">Low</span>' : '<span class="badge badge-success">OK</span>']], p)}</div>`;
}
async function dashboard() {
  const d = await api('dashboard.php'), max = Math.max(1, ...d.last7.map(x => x.total));
  root().innerHTML = head('Dashboard', 'Live overview of your business.') +
    cards(stat('Stock value', money(d.stock_value), d.products + ' active products') + stat('Sales today', money(d.today_sales), 'This month: ' + money(d.month_sales)) +
      stat('Profit this month', money(d.profit), 'After cost of goods and expenses') + stat('Low / out of stock', d.low + ' / ' + d.out, 'Needs attention')) +
    two(card('Sales — last 7 days', `<div style="display:flex;gap:8px;align-items:flex-end;height:150px">${d.last7.map(x =>
        `<div style="flex:1;text-align:center" title="${money(x.total)}"><div style="height:${Math.round(x.total / max * 110)}px;min-height:2px;background:var(--primary);border-radius:6px 6px 0 0"></div><div style="font-size:11px;color:var(--muted)">${x.day.slice(5)}</div></div>`).join('')}</div>`) +
      card('Low stock', tbl([['Product', r => esc(r.name)], ['Stock', r => `<b>${r.stock}</b> / min ${r.min_stock}`]], d.low_items, 'All stocked up.')) +
      card('Recent sales', tbl([['Invoice', r => esc(r.invoice_no)], ['Customer', r => esc(r.customer || 'Walk-in')], ['Total', r => money(r.total)]], d.recent, 'No sales yet.')) +
      card('Top sellers (30 days)', tbl([['Product', r => esc(r.name)], ['Sold', r => r.qty], ['Revenue', r => money(r.revenue)]], d.top, 'No sales yet.')));
}

document.addEventListener('DOMContentLoaded', () => setTimeout(async () => {
  const k = window.PAGE_KIND; if (!k || !root()) return;
  try {
    if (k.startsWith('crud:')) await crudPage(k.slice(5));
    else await ({stock: stockPage, sale: () => docPage('sale'), purchase: () => docPage('purchase'), sales: () => salesList(false), 'rpt-sales': () => salesList(true),
      purchases: purchasesList, 'rpt-inv': inventoryReport, dashboard}[k])();
  } catch (e) { bad(e); }
}, 300));
