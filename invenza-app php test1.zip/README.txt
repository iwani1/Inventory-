INVENZA on GreenGeeks (PHP 8.1 + SQLite)
1. cPanel > File Manager: upload the CONTENTS of public_html/ into your site's public_html (or a subfolder). Overwrite existing files.
2. cPanel > Select PHP Version: 8.1, tick pdo_sqlite.
3. First time only: open https://yourdomain/api/install.php, create the admin, then DELETE api/install.php.
   (Already installed from the earlier zip? Skip this: new tables are created automatically on first use.)
4. Log in at https://yourdomain/pages/login.html
5. Set your business name and currency at the top of assets/js/pages.js (BIZ, CUR).
Backup: copy /home/<user>/invenza-data/invenza.sqlite regularly (cPanel Cron Jobs).
