<?php
declare(strict_types=1);
// Database lives OUTSIDE public_html: /home/<user>/invenza-data/invenza.sqlite
const DATA_DIR = __DIR__ . '/../../invenza-data';

function db(): PDO {
    static $pdo = null;
    if ($pdo) return $pdo;
    if (!is_dir(DATA_DIR)) @mkdir(DATA_DIR, 0750, true);
    $pdo = new PDO('sqlite:' . DATA_DIR . '/invenza.sqlite');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    $pdo->exec('PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000; PRAGMA foreign_keys=ON;');
    return $pdo;
}
function json_out($data, int $code = 200): never {
    http_response_code($code);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}
function fail(string $msg, int $code = 400): never { json_out(['error' => $msg], $code); }
function body(): array {
    $r = json_decode(file_get_contents('php://input') ?: '', true);
    return is_array($r) ? $r : [];
}
function start_session(): void {
    if (session_status() === PHP_SESSION_NONE) {
        session_name('invenza');
        session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax', 'secure' => !empty($_SERVER['HTTPS'])]);
        session_start();
    }
}
function require_login(): array {
    start_session();
    if (empty($_SESSION['uid'])) fail('Not authenticated', 401);
    // Simple CSRF defence: state-changing calls must come from our JS
    if ($_SERVER['REQUEST_METHOD'] !== 'GET' && ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') !== 'fetch') fail('Bad request', 403);
    $st = db()->prepare('SELECT id,name,email,role FROM users WHERE id=? AND active=1');
    $st->execute([$_SESSION['uid']]);
    $u = $st->fetch();
    if (!$u) { session_destroy(); fail('Not authenticated', 401); }
    return $u;
}
function require_role(array $u, array $roles): void {
    if (!in_array($u['role'], $roles, true)) fail('You do not have permission to do that', 403);
}
