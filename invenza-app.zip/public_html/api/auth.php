<?php
require __DIR__ . '/db.php';
start_session();
$action = $_GET['action'] ?? 'me';
if ($action === 'login' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $b = body();
    $st = db()->prepare('SELECT * FROM users WHERE email=? AND active=1');
    $st->execute([strtolower(trim($b['email'] ?? ''))]);
    $u = $st->fetch();
    if (!$u || !password_verify($b['password'] ?? '', $u['password_hash'])) { sleep(1); fail('Invalid email or password', 401); }
    session_regenerate_id(true);
    $_SESSION['uid'] = (int)$u['id'];
    json_out(['id' => $u['id'], 'name' => $u['name'], 'email' => $u['email'], 'role' => $u['role']]);
}
if ($action === 'logout') {
    $_SESSION = []; session_destroy();
    json_out(['ok' => true]);
}
json_out(require_login());
