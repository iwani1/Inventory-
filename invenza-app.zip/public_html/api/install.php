<?php
// Run ONCE in the browser, create the admin, then DELETE this file.
require __DIR__ . '/db.php';
$pdo = db();
$pdo->exec("
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, name TEXT NOT NULL, email TEXT NOT NULL UNIQUE, password_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'staff', active INTEGER NOT NULL DEFAULT 1, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS categories(id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE);
CREATE TABLE IF NOT EXISTS brands(id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE);
CREATE TABLE IF NOT EXISTS units(id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE);
CREATE TABLE IF NOT EXISTS products(
  id INTEGER PRIMARY KEY, sku TEXT NOT NULL UNIQUE, name TEXT NOT NULL, barcode TEXT,
  category_id INTEGER REFERENCES categories(id) ON DELETE SET NULL,
  brand_id INTEGER REFERENCES brands(id) ON DELETE SET NULL,
  unit_id INTEGER REFERENCES units(id) ON DELETE SET NULL,
  purchase_price REAL NOT NULL DEFAULT 0, selling_price REAL NOT NULL DEFAULT 0,
  tax REAL DEFAULT 0, discount REAL DEFAULT 0,
  stock REAL NOT NULL DEFAULT 0, min_stock REAL DEFAULT 0, max_stock REAL DEFAULT 0,
  description TEXT, image TEXT, status TEXT NOT NULL DEFAULT 'Active', created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS stock_movements(
  id INTEGER PRIMARY KEY, product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  type TEXT NOT NULL, qty REAL NOT NULL, note TEXT, user_id INTEGER, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE INDEX IF NOT EXISTS idx_mov_product ON stock_movements(product_id);
");
$has = (int)$pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();
$msg = '';
if ($has) {
    $msg = 'Already installed. Delete install.php from the server.';
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $n = trim($_POST['name'] ?? ''); $e = strtolower(trim($_POST['email'] ?? '')); $p = $_POST['password'] ?? '';
    if (!$n || !filter_var($e, FILTER_VALIDATE_EMAIL) || strlen($p) < 8) {
        $msg = 'Enter a name, a valid email and a password of at least 8 characters.';
    } else {
        $pdo->prepare("INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?, 'admin')")
            ->execute([$n, $e, password_hash($p, PASSWORD_DEFAULT)]);
        foreach (['Electronics','Accessories','Furniture','Stationery'] as $x) $pdo->prepare('INSERT OR IGNORE INTO categories(name) VALUES(?)')->execute([$x]);
        foreach (['Piece','Box','Pack','Kilogram','Liter','Meter','Dozen'] as $x) $pdo->prepare('INSERT OR IGNORE INTO units(name) VALUES(?)')->execute([$x]);
        $has = 1; $msg = 'Done! Admin created. DELETE api/install.php now, then log in at pages/login.html.';
    }
}
?><!DOCTYPE html><meta charset="utf-8"><title>Install Invenza</title>
<body style="font-family:sans-serif;max-width:380px;margin:60px auto">
<h2>Invenza setup</h2><?php if ($msg) echo '<p><b>' . htmlspecialchars($msg) . '</b></p>'; ?>
<?php if (!$has): ?><form method="post">
<p><input name="name" placeholder="Your name" style="width:100%;padding:8px"></p>
<p><input name="email" type="email" placeholder="Admin email" style="width:100%;padding:8px"></p>
<p><input name="password" type="password" placeholder="Password (8+ chars)" style="width:100%;padding:8px"></p>
<button style="padding:8px 16px">Create admin</button></form><?php endif; ?></body>
