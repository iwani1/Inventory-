INVENZA on GreenGeeks (PHP 8.1 + SQLite)
1. cPanel > File Manager > upload the CONTENTS of public_html/ into your site's public_html (or a subfolder).
2. In cPanel > Select PHP Version: use 8.1 and make sure pdo_sqlite is ticked.
3. Visit https://yourdomain/api/install.php, create the admin, then DELETE api/install.php.
   (The database is created at /home/<user>/invenza-data/invenza.sqlite, outside public_html.)
4. Log in at https://yourdomain/pages/login.html
Backup: copy invenza-data/invenza.sqlite regularly (cPanel cron).
